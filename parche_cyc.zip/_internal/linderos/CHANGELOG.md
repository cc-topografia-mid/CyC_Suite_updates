# 🚧 CHANGELOG - Módulo Linderos
**CyC Topografía Suite**

Todas las actualizaciones notables del módulo de **Control y Replanteo de Colindancias (Linderos)** se documentarán en este archivo. El sistema de versionado sigue la nomenclatura interna de compilación `vYYMMDD.HHMM`.

---

## [v260428.1833]

### Añadido
* Integración de una vista previa de exportación en el panel derecho del módulo, con representación multipágina y renderizado del reporte técnico dentro de una maqueta tipo hoja.
* Incorporación de controles de configuración PDF en tiempo real para papel, paleta visual, tamaño de texto, márgenes, paginación, ajuste de texto y títulos en negrita.
* Inclusión de la vista gráfica del ajuste dentro del reporte técnico mediante marcador Markdown y renderizado tanto en la vista previa como en la exportación.
* Integración del sistema `i18n` de la Suite en la interfaz de Linderos, con suscripción activa a cambios globales de idioma.
* Traducción del generador de reportes en `modelo.py`, permitiendo que el contenido exportado respete el idioma activo de la Suite.

### Cambiado
* Migración de la interfaz principal del módulo a `CustomTkinter`, conservando la estructura operativa existente pero alineándola con el estándar visual moderno de la Suite.
* Rediseño del layout principal para usar un panel derecho ajustable en lugar de un ancho fijo, mejorando la visibilidad del formulario y del visor de reporte.
* Reestructuración del reporte técnico para generarse en sintaxis Markdown enriquecida, con encabezados, listas, tablas y bloques consistentes para TXT, vista previa y PDF.
* Homologación visual de la exportación de Linderos con otros módulos de la Suite, incluyendo configuración de paletas y comportamiento de vista previa más cercano al resultado final exportado.
* Ajuste del bloque “Proyecto y Sesión” para mejorar legibilidad de botones y evitar recortes de texto en acciones de guardado y carga.

### Corregido
* Corrección del desbordamiento y traslape entre el título del documento y el cuerpo del reporte en la vista previa.
* Solucionado el problema donde la vista previa mostraba artefactos de Markdown sin procesar, como encabezados `###` visibles y tablas renderizadas como texto plano.
* Ajustado el paginado del reporte para evitar cortes de bloques, tablas o secciones fuera del área útil de la página.
* Corregido el comportamiento de las opciones de configuración PDF para evitar colapsos y ocultamiento parcial de controles en la interfaz.
* Solucionado el renderizado de la imagen del gráfico dentro de la vista previa cuando el reporte final incluía la sección de vista gráfica.
* Corregido el cambio dinámico de idioma en pestañas y controles del módulo, incluyendo el fallo `KeyError: 'Datos'` provocado por el renombrado de pestañas en `CTkTabview`.
* Reparada la actualización en tiempo real de textos visibles, encabezados y elementos de previsualización al cambiar entre español, inglés y portugués.

## [v260408.1630]

### ✨ Añadido
* **Alerta de Invasión (Offset):** Implementación de un algoritmo que calcula la distancia perpendicular de un punto levantado hacia la línea teórica del lindero, resaltando la fila en rojo si la invasión o el desfase supera la tolerancia constructiva.
* **Modo Aprendizaje:** Integración de la clase `ToolTip` en todos los controles principales para asistir al operador en el análisis de colindancias, respetando el estándar visual de la Suite.

### 🛠️ Modificado
* **UI/UX:** Adopción del formato de "Pantalla Dividida" (50% Área de Tablas / 50% Panel de Análisis Geométrico y Legal).
* **Motor de Rumbos:** Optimización de la lógica trigonométrica para la asignación y visualización correcta de los cuadrantes geográficos (NE, SE, SW, NW).

---

## [v260407.1100]

### 🐛 Corregido
* **Singularidad Matemática:** Solucionado el error de división por cero (`ZeroDivisionError`) que colapsaba el sistema al intentar calcular la pendiente (m) en linderos que eran perfectamente verticales alineados al eje Norte-Sur (X1 = X2).
* **Gestión de Memoria:** Corrección de un fallo que duplicaba los puntos *as-built* en la tabla al recargar un archivo CSV modificado sin haber limpiado la sesión previa de la memoria.

---

## [v260406.0900]

### ✨ Añadido
* 🚀 Lanzamiento inicial del Módulo Linderos.
* Estructura base del patrón MVC (Modelo, Vista, Controlador).
* Ingesta de archivos CSV con coordenadas teóricas del polígono de diseño.
* Rutina analítica básica para el cálculo de distancias perimetrales entre vértices de la propiedad.