# main.py
import tkinter as tk
from tkinter import ttk, messagebox
import ttkbootstrap as tb           # Mantenemos tb para que no crasheen los submódulos aún
from ttkbootstrap.constants import *
import customtkinter as ctk         # <-- NUEVA LIBRERÍA CORE
from PIL import Image               # <-- IMPORTACIÓN PARA MANEJO DE LOGOS
from i18.i18n_controlador import i18n
import os
import sys

def obtener_ruta_recurso(ruta_relativa):
    """
    Enruta dinámicamente los archivos. Si es el .exe (RELEASE), busca en _internal.
    Si es código fuente (DEV), busca en la carpeta de trabajo actual.
    """
    try:
        ruta_base = sys._MEIPASS
    except Exception:
        ruta_base = os.path.abspath(".")
    return os.path.join(ruta_base, ruta_relativa)

from linderos.vista import TabAjusteLinderos
from linderos.controlador import ControladorLinderos
from gnss.vista import TabFactoresGNSS
from gnss.controlador import ControladorGNSS
from datalink.vista import TabDataLink               
from datalink.controlador import ControladorDataLink 
from rinex.vista import TabUnionRinex
from rinex.controlador import ControladorRinex
from postproceso.vista import TabPostproceso               
from postproceso.controlador import ControladorPostproceso 
from conversiones.vista import TabConversor
from conversiones.controlador import ControladorConversor
from presupuestos import PresupuestosApp

# --- IMPORTACIÓN DINÁMICA DE VERSIONES DE MÓDULOS ---
from linderos.constants import VERSION as V_LINDEROS
from gnss.constants import VERSION as V_GNSS
from datalink.constants import VERSION as V_DATALINK
from postproceso.constants import VERSION as V_POSTPROCESO
from rinex.constants import VERSION_ORQUESTADOR as V_RINEX 
from conversiones.constants import VERSION as V_CONVERSIONES
from presupuestos.constants import VERSION as V_PRESUPUESTOS

from seguridad import seguridad
import cyc_updater
from monetizacion import servicio_paypal

# ==========================================
# CONTROL DE VERSIONES Y CONFIGURACIÓN CTK
# ==========================================
VERSION_LAUNCHER = "260424.0800"

# Configuración Global CTk
ctk.set_appearance_mode("Light")  # Modo claro obligatorio para estilo SaaS
ctk.set_default_color_theme("blue") 

# Paleta SaaS
COLOR_BASE_BG     = "#f4f7f6" # Fondo global ligerísimamente gris
COLOR_SURFACE     = "#ffffff" # Fondo de tarjetas blanco puro
COLOR_ACENTO_PPAL = "#326334" # Verde Institucional CyC (basado en 326334ff)
COLOR_ACENTO_HOVER= "#244926" # Tono de interacción más oscuro para los botones
COLOR_TEXTO_MAIN  = "#2b2b2b"
COLOR_TEXTO_SEC   = "#6c757d"
COLOR_BORDES      = "#e0e4e8"

class AppTopografia(ctk.CTk):
    """CyC Hub - Dashboard Comercial SaaS"""
    def __init__(self):
        super().__init__()
        self.title(f"CyC Hub v{VERSION_LAUNCHER}")
        self.geometry("1400x900") 
        
        self.after(0, lambda: self.state('zoomed'))
        self.configure(fg_color=COLOR_BASE_BG) 
        
        self.style = tb.Style(theme="litera")

        self.var_modo_aprendizaje = ctk.BooleanVar(value=False)
        self.memoria_compartida = {
            "rover_ruta": "", "base_ruta": "", "nav_rutas": [], "sp3_ruta": "",
            "base_lat": 0.0, "base_lon": 0.0, "base_elev": 0.0, "altura_baston": 0.0
        }
        
        self.licencia = seguridad.verificar_licencia()
        if not self.licencia.get("valido", False):
            self._bloquear_suite_entera(self.licencia.get("mensaje", "Acceso Restringido"), self.licencia.get("hwid", "---"))
            return
            
        cyc_updater.verificar_actualizaciones(VERSION_LAUNCHER, self)
        i18n.registrar_vista(self.actualizar_idioma_ui)
        self.botones_sidebar = {} 
            
        self._definir_catalogo_modulos()
        self._construir_dashboard()

    def _definir_catalogo_modulos(self):
        self.catalogo = {
            "postproceso": {
                "titulo": i18n.t("cat_post_titulo"), "icono": "📡📍⚙️", "version": V_POSTPROCESO,
                "desc_corta": i18n.t("cat_post_desc"),
                "desc_larga": i18n.t("cat_post_desc_larga"),
                "features": i18n.t("cat_post_feat"),
                "comando": self._abrir_postproceso
            },
            "rinex": {
                "titulo": i18n.t("cat_rinex_titulo"), "icono": "📡️🧾🌐️", "version": V_RINEX,
                "desc_corta": i18n.t("cat_rinex_desc"),
                "desc_larga": i18n.t("cat_rinex_desc_larga"),
                "features": i18n.t("cat_rinex_feat"),
                "comando": self._abrir_rinex
            },
            "linderos": {
                "titulo": i18n.t("cat_linderos_titulo"), "icono": "📐📍📏", "version": V_LINDEROS,
                "desc_corta": i18n.t("cat_linderos_desc"),
                "desc_larga": i18n.t("cat_linderos_desc_larga"),
                "features": i18n.t("cat_linderos_feat"),
                "comando": self._abrir_linderos
            },
            "datalink": {
                "titulo": i18n.t("cat_datalink_titulo"), "icono": "📡🔄🖥️", "version": V_DATALINK,
                "desc_corta": i18n.t("cat_datalink_desc"),
                "desc_larga": i18n.t("cat_datalink_desc_larga"),
                "features": i18n.t("cat_datalink_feat"),
                "comando": self._abrir_datalink
            },
            "gnss": {
                "titulo": i18n.t("cat_gnss_titulo"), "icono": "📐🔢⚙️", "version": V_GNSS,
                "desc_corta": i18n.t("cat_gnss_desc"),
                "desc_larga": i18n.t("cat_gnss_desc_larga"),
                "features": i18n.t("cat_gnss_feat"),
                "comando": self._abrir_gnss
            },
            "conversiones": {
                "titulo": i18n.t("cat_conversiones_titulo"), "icono": "🔄🌐🗺️", "version": V_CONVERSIONES,
                "desc_corta": i18n.t("cat_conversiones_desc"),
                "desc_larga": i18n.t("cat_conversiones_desc_larga"),
                "features": i18n.t("cat_conversiones_feat"),
                "comando": self._abrir_conversiones
            },
            "presupuestos": {
                "titulo": i18n.t("cat_presupuestos_titulo"), "icono": "💵📊📝", "version": V_PRESUPUESTOS,
                "desc_corta": i18n.t("cat_presupuestos_desc"),
                "desc_larga": i18n.t("cat_presupuestos_desc_larga"),
                "features": i18n.t("cat_presupuestos_feat"),
                "comando": self._abrir_presupuestos
            }
        }
        # --- DEFINICIÓN DE GRUPOS LÓGICOS (WORKFLOW) ---
        self.grupos = {
            "todos": {
                "clave_titulo": "grp_todos", 
                "icono": "🏠",
                "modulos": list(self.catalogo.keys()) # <-- DINÁMICO: Absorbe todo el catálogo automáticamente
            },
            "gnss": {
                "clave_titulo": "grp_gnss", 
                "icono": "🛰️",
                "modulos": ["rinex", "postproceso", "gnss"] # Orden en que aparecerán
            },
            "conversion": {
                "clave_titulo": "grp_conversion", 
                "icono": "🔄",
                "modulos": ["conversiones", "datalink"]
            },
            "analisis": {
                "clave_titulo": "grp_analisis", 
                "icono": "📐",
                "modulos": ["linderos"]
            },
            "gestion": {
                "clave_titulo": "grp_gestion", 
                "icono": "💼",
                "modulos": ["presupuestos"]
            }
        }

    def _construir_dashboard(self):
        self.sidebar = ctk.CTkFrame(self, width=260, corner_radius=0, fg_color="#182b21") 
        self.sidebar.pack(side=LEFT, fill=Y)
        self.sidebar.pack_propagate(False)

        try:
            ruta_logo = obtener_ruta_recurso("logo.png") 
            imagen_logo = Image.open(ruta_logo)
            ancho_orig, alto_orig = imagen_logo.size
            proporcion = ancho_orig / alto_orig
            alto_objetivo = 130 
            ancho_objetivo = int(alto_objetivo * proporcion)
            
            logo_ctk = ctk.CTkImage(light_image=imagen_logo, dark_image=imagen_logo, size=(ancho_objetivo, alto_objetivo))
            lbl_logo = ctk.CTkLabel(self.sidebar, text="", image=logo_ctk)
            lbl_logo.pack(pady=(35, 5)) 
            padding_titulo = (0, 30)    
        except Exception as e:
            print(f"Aviso: No se encontró el logo en la ruta. {e}")
            padding_titulo = (40, 30)   

        lbl_titulo = ctk.CTkLabel(self.sidebar, text="Suite", font=('Segoe UI', 30, 'normal'), text_color="white", justify=CENTER)
        lbl_titulo.pack(pady=padding_titulo, padx=10)

        self.f_info = ctk.CTkFrame(self.sidebar, fg_color="#243f30", corner_radius=8)
        self.f_info.pack(fill=X, padx=20, pady=10)
        self._dibujar_info_usuario()
        
        self.chk_aprender = ctk.CTkSwitch(self.sidebar, text=i18n.t("sw_ayudas_visuales"), variable=self.var_modo_aprendizaje, progress_color=COLOR_ACENTO_PPAL, font=('Segoe UI', 12), text_color="white")
        self.chk_aprender.pack(pady=(10, 5), padx=30, anchor=W)

        self.mapa_idiomas = {"ES": "es", "EN": "en", "PT": "pt"}
        self.mapa_idiomas_inverso = {"es": "ES", "en": "EN", "pt": "PT"}
        idioma_actual = i18n.get_idioma_actual()
        valor_defecto = self.mapa_idiomas_inverso.get(idioma_actual, "ES")

        def al_cambiar_idioma(seleccion):
            codigo = self.mapa_idiomas.get(seleccion, "es")
            i18n.set_idioma(codigo)

        self.seg_idioma = ctk.CTkSegmentedButton(
            self.sidebar, values=["ES", "EN", "PT"], command=al_cambiar_idioma,
            selected_color=COLOR_ACENTO_PPAL, selected_hover_color=COLOR_ACENTO_HOVER,
            unselected_color="#243f30", unselected_hover_color="#2c4d3b", font=('Segoe UI', 11, 'bold')
        )
        self.seg_idioma.set(valor_defecto) 
        self.seg_idioma.pack(pady=(5, 10), padx=30, fill=X)

        f_line = ctk.CTkFrame(self.sidebar, height=1, fg_color="#365443")
        f_line.pack(fill=X, padx=30, pady=(15, 20))

        self.lbl_nav_titulo = ctk.CTkLabel(self.sidebar, text=i18n.t("menu_navegacion"), font=('Segoe UI', 11, 'bold'), text_color="#8ea898")
        self.lbl_nav_titulo.pack(anchor=W, padx=25, pady=(0, 10))

        # Navegación por Grupos Lógicos
        self._crear_boton_grupo("grp_todos", "🏠", "todos")
        self._crear_boton_grupo("grp_gnss", "🛰️", "gnss")
        self._crear_boton_grupo("grp_conversion", "🔄", "conversion")
        self._crear_boton_grupo("grp_analisis", "📐", "analisis")
        self._crear_boton_grupo("grp_gestion", "💼", "gestion")

        comando_acerca = lambda: self._navegar_seguro(self._abrir_acerca_de)
        self.btn_acerca = ctk.CTkButton(self.sidebar, text=f"ℹ️ {i18n.t('menu_ayuda')}", command=comando_acerca, fg_color="transparent", hover_color="#243f30", text_color="white", corner_radius=6, anchor=W, font=('Segoe UI', 13))
        self.btn_acerca.pack(pady=2, padx=20, fill=X, ipady=3)

        f_footer = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        f_footer.pack(side=BOTTOM, fill=X, pady=20, padx=20)
        
        def abrir_correo(event):
            import webbrowser
            webbrowser.open("mailto:christian@topografia.cc")
            
        # Ahora usamos i18n y lo asignamos a 'self' para poder actualizarlo
        self.lbl_creditos = ctk.CTkLabel(f_footer, text=i18n.t("lbl_creditos"), font=('Segoe UI', 13), text_color="#8ea898", wraplength=220, justify=LEFT, cursor="hand2")
        self.lbl_creditos.pack(anchor=W, pady=(0, 10))
        self.lbl_creditos.bind("<Button-1>", abrir_correo)
        
        self.lbl_version = ctk.CTkLabel(f_footer, text=i18n.t("lbl_version_hub", version=VERSION_LAUNCHER), font=('Segoe UI', 13, 'bold'), text_color="#5a7061")
        self.lbl_version.pack(anchor=W)
        
        if not getattr(sys, 'frozen', False):
            self.lbl_version.configure(cursor="crosshair")
            self.lbl_version.bind("<Double-Button-1>", self._abrir_panel_pruebas_monetizacion)
            
        # NUEVO: Hotkey alternativo global para el "Easter Egg" / Dev Tools
        # Al estar fuera del "if not frozen", este atajo funcionará en la versión compilada
        self.bind("<Control-Shift-D>", self._abrir_panel_pruebas_monetizacion)

        # --- ÁREA DE TRABAJO ---
        self.main_content = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.main_content.pack(side=RIGHT, fill=BOTH, expand=YES)
        
        # Estado del panel lateral
        self.sidebar_visible = True

        # Header superior (Contenedor del nuevo banner horizontal)
        self.f_top = ctk.CTkFrame(self.main_content, fg_color=COLOR_SURFACE, height=70, corner_radius=0)
        self.f_top.pack(side=TOP, fill=X)
        self.f_top.pack_propagate(False)
        
        # Botón para ocultar/mostrar panel lateral
        self.btn_toggle_sidebar = ctk.CTkButton(self.f_top, text=i18n.t("btn_ocultar_panel"), height=40, font=('Segoe UI', 13, 'bold'), fg_color="transparent", text_color=COLOR_TEXTO_MAIN, hover_color=COLOR_BORDES, command=self._toggle_sidebar)
        self.btn_toggle_sidebar.pack(side=LEFT, padx=(20, 10), pady=15)

        self.lbl_modulo_actual = ctk.CTkLabel(self.f_top, text="", font=('Segoe UI', 20, 'bold'), text_color=COLOR_TEXTO_MAIN)
        self.lbl_modulo_actual.pack(side=LEFT, padx=10, pady=20)
        
        self.f_docs_modulo = ctk.CTkFrame(self.f_top, fg_color="transparent")
        self.f_docs_modulo.pack(side=RIGHT, padx=30, pady=10)
        
        self.frame_herramienta = ctk.CTkFrame(self.main_content, fg_color="transparent", corner_radius=0)
        self.frame_herramienta.pack(fill=BOTH, expand=YES, padx=30, pady=20)
        
        self._cargar_inicio()

    def _toggle_sidebar(self):
        """Oculta o muestra el panel lateral izquierdo."""
        if self.sidebar_visible:
            self.sidebar.pack_forget()
            self.sidebar_visible = False
            self.btn_toggle_sidebar.configure(text="❱", font=('Segoe UI', 20)) # Ícono de expandir
            
            # Mostrar logo horizontal si el banner de monetización NO está activo
            if hasattr(self, 'lbl_apoyo') and self.lbl_apoyo.winfo_exists() and getattr(self, 'lbl_logo_horizontal', None):
                self.lbl_logo_horizontal.pack(side=RIGHT, padx=20, pady=5)
        else:
            # Volvemos a empaquetar la sidebar antes del main_content para mantener la estructura
            self.sidebar.pack(side=LEFT, fill=Y, before=self.main_content)
            self.sidebar_visible = True
            self.btn_toggle_sidebar.configure(text=i18n.t("btn_ocultar_panel"), font=('Segoe UI', 13, 'bold'))
            
            # Ocultar logo horizontal
            if getattr(self, 'lbl_logo_horizontal', None) and self.lbl_logo_horizontal.winfo_exists():
                self.lbl_logo_horizontal.pack_forget()

    def _navegar_seguro(self, comando_destino):
        """Verifica si hay una herramienta activa antes de cambiar la vista principal."""
        # Consideramos herramientas a todo lo que no sea el hub o la vista "acerca"
        if hasattr(self, 'modulo_actual_cod') and self.modulo_actual_cod:
            if not str(self.modulo_actual_cod).startswith("hub") and self.modulo_actual_cod != "acerca":
                respuesta = messagebox.askyesno("Confirmar Navegación", "¿Deseas salir de la herramienta actual?\n\nCualquier proceso no guardado se perderá.")
                if not respuesta:
                    return
        comando_destino()

    def _dibujar_info_usuario(self, donador_simulado=None):
        for widget in self.f_info.winfo_children():
            widget.destroy()
            
        estado_acceso = self.licencia.get("estado", "BASICO")
        es_donador = estado_acceso in ["DONADOR_PRO", "ADMIN"]
        
        if donador_simulado is not None:
            es_donador = donador_simulado
            
        pad_top_nombre = 10
        if es_donador:
            try:
                ruta_img = obtener_ruta_recurso("donate_user.png")
                img = Image.open(ruta_img)
                ancho, alto = img.size
                alto_obj = 30
                ancho_obj = int(alto_obj * (ancho / alto))
                img_ctk = ctk.CTkImage(light_image=img, dark_image=img, size=(ancho_obj, alto_obj))
                
                lbl_img = ctk.CTkLabel(self.f_info, text="", image=img_ctk)
                lbl_img.pack(anchor=W, padx=15, pady=(10, 0))
                pad_top_nombre = 2 
            except Exception as e:
                pass
                
        nombre_cliente = self.licencia.get('cliente', 'Usuario')
        
        # Etiqueta interactiva para el nombre de usuario
        lbl_usuario_nombre = ctk.CTkLabel(self.f_info, text=f"👤 {i18n.t('lbl_usuario')} {nombre_cliente}", font=('Segoe UI', 13, 'bold'), text_color="white", cursor="hand2")
        lbl_usuario_nombre.pack(anchor=W, padx=15, pady=(pad_top_nombre,0))
        
        # Efectos visuales y lógicos (Hover y Doble Clic)
        lbl_usuario_nombre.bind("<Enter>", lambda e: lbl_usuario_nombre.configure(text_color="#ffc439")) # Se pinta de amarillo al pasar el mouse
        lbl_usuario_nombre.bind("<Leave>", lambda e: lbl_usuario_nombre.configure(text_color="white"))
        lbl_usuario_nombre.bind("<Double-Button-1>", self._mostrar_popup_hwid)
        
        if estado_acceso == "EVALUACION":
            expiracion = self.licencia.get('expiracion', '---')
            texto_badge = f"⚠️⏳ Modo Evaluación"
            color_badge = "#a855f7" # Púrpura vibrante
        elif estado_acceso == "BASICO":
            texto_badge = "⚠️🔒 Modo Básico (Restringido)"
            color_badge = "#ef4444" # Rojo alerta
        elif estado_acceso in ["DONADOR_PRO", "ADMIN"]:
            texto_badge = "⭐🔓 Eres Patrocinador"
            color_badge = "#eab308" # Amarillo Mostaza
        else:
            texto_badge = "⚫ Estado Desconocido"
            color_badge = "#9ca3af"

        ctk.CTkLabel(self.f_info, text=texto_badge, font=('Segoe UI', 12, 'bold'), text_color=color_badge).pack(anchor=W, padx=15, pady=(0,10))

    def _mostrar_popup_hwid(self, event=None):
        """Abre una ventana modal elegante para copiar el HWID del equipo."""
        hwid_usuario = self.licencia.get("hwid", "ERROR-HWID")

        # Usamos CTkToplevel para mantener el estilo moderno (bordes oscuros)
        top = ctk.CTkToplevel(self)
        top.title("ID de Instalación")
        top.geometry("420x220")
        top.attributes('-topmost', True)
        top.grab_set() # Bloquea la ventana principal hasta que se cierre esta
        
        # Centrar la ventana respecto al monitor
        top.update_idletasks()
        x = (top.winfo_screenwidth() // 2) - (420 // 2)
        y = (top.winfo_screenheight() // 2) - (220 // 2)
        top.geometry(f"+{x}+{y}")

        ctk.CTkLabel(top, text="💻 Tu ID de Instalación (HWID)", font=('Segoe UI', 16, 'bold'), text_color=COLOR_ACENTO_PPAL).pack(pady=(20, 10))
        ctk.CTkLabel(top, text="Este identificador es único para tu equipo. Cópialo\npara vincular tu licencia a esta máquina.", font=('Segoe UI', 12), text_color=COLOR_TEXTO_SEC, justify=CENTER).pack(pady=(0, 15))

        ent_hwid = ctk.CTkEntry(top, font=('Consolas', 14, 'bold'), justify=CENTER, text_color=COLOR_TEXTO_MAIN, width=300, height=35)
        ent_hwid.insert(0, hwid_usuario)
        ent_hwid.configure(state="readonly")
        ent_hwid.pack(pady=5)

        def copiar_y_cerrar():
            self.clipboard_clear()
            self.clipboard_append(hwid_usuario)
            messagebox.showinfo("ID Copiado", "El HWID ha sido copiado al portapapeles exitosamente.", parent=top)
            top.destroy()

        btn_copiar = ctk.CTkButton(top, text="📋 Copiar al Portapapeles", command=copiar_y_cerrar, fg_color=COLOR_ACENTO_PPAL, hover_color=COLOR_ACENTO_HOVER, font=('Segoe UI', 13, 'bold'))
        btn_copiar.pack(pady=(15, 10))

    def _crear_boton_grupo(self, clave_texto, icono, cod_grupo):
        """Crea un botón en la barra lateral que filtra el Hub por grupo."""
        texto_traducido = f"{icono} {i18n.t(clave_texto)}"
        
        # Al hacer clic, cargamos el inicio protegido por _navegar_seguro
        comando = lambda: self._navegar_seguro(lambda: self._cargar_inicio(grupo_filtro=cod_grupo))
        
        btn = ctk.CTkButton(self.sidebar, text=texto_traducido, command=comando, fg_color="transparent", hover_color="#243f30", text_color="white", corner_radius=6, anchor=W, font=('Segoe UI', 13), cursor="hand2")
        btn.pack(pady=2, padx=20, fill=X, ipady=3)
        
        # Lo guardamos en el mismo diccionario para que el sistema de idiomas lo encuentre y lo traduzca
        self.botones_sidebar[cod_grupo] = {'widget': btn, 'clave': clave_texto, 'icono': icono, 'autorizado': True}

    def _abrir_panel_pruebas_monetizacion(self, event=None):
        from monetizacion import controlador as mon_ctrl
        from monetizacion import vista as mon_vista
        from monetizacion import servicio_paypal

        top = tb.Toplevel(self)
        top.title("🛠️ Dev Tools: Simulador de Monetización")
        top.geometry("750x450")
        top.attributes('-topmost', True)

        tb.Label(top, text="Panel de Pruebas: Banners Contextuales y Estados", font=('Segoe UI', 16, 'bold')).pack(pady=10)

        frame_estados = tb.LabelFrame(top, text="Forzar Estado de Acceso Global (Paywalls)")
        frame_estados.pack(fill=X, padx=20, pady=(0, 10), ipadx=10, ipady=10)
        
        estado_var = tk.StringVar(value=self.licencia.get("estado", "BASICO"))
        
        def al_cambiar_estado():
            nuevo_estado = estado_var.get()
            self.licencia["estado"] = nuevo_estado
            self._dibujar_info_usuario()
            if self.lbl_modulo_actual.cget("text") == "Acerca de CyC Topografía Suite":
                self._abrir_acerca_de()
            print(f"[DEV] Estado forzado a: {nuevo_estado}")

        tb.Radiobutton(frame_estados, text="🟢 EVALUACION", variable=estado_var, value="EVALUACION", command=al_cambiar_estado).pack(side=LEFT, expand=True)
        tb.Radiobutton(frame_estados, text="🟡 BASICO", variable=estado_var, value="BASICO", command=al_cambiar_estado).pack(side=LEFT, expand=True)
        tb.Radiobutton(frame_estados, text="🌟 PRO", variable=estado_var, value="DONADOR_PRO", command=al_cambiar_estado).pack(side=LEFT, expand=True)

        tb.Label(top, text="⚠️ Inyección en Tiempo Real:\nAl hacer clic, el banner aparecerá directamente en la barra superior (Header) del HUB de la Suite.", justify=CENTER, foreground="gray").pack(pady=15)

        frame_botones = tb.Frame(top)
        frame_botones.pack(fill=X, padx=20, pady=10)

        modulos_test = ["postproceso", "linderos", "datalink", "rinex", "gnss"]

        def simular_banner(mod):
            mensaje = mon_ctrl.generar_mensaje(mod, "test", {"tiempo": 120})
            
            def mock_donar(monto, frame):
                print(f"[DEV] Abriendo PayPal. Monto: {monto}")
                servicio_paypal.abrir_donacion(monto)
                frame.destroy()
                self._limpiar_area_trabajo(self.lbl_modulo_actual.cget("text"), mod)
                
            def mock_cerrar(frame):
                frame.destroy()
                self._limpiar_area_trabajo(self.lbl_modulo_actual.cget("text"), mod)
                
            # Renderizamos directamente en el f_docs_modulo de la ventana principal
            mon_vista.renderizar(self.f_docs_modulo, mensaje, mock_donar, mock_cerrar)

        for mod in modulos_test:
            btn = tb.Button(frame_botones, text=mod.capitalize(), bootstyle="outline-primary",
                            command=lambda m=mod: simular_banner(m))
            btn.pack(side=LEFT, padx=3, fill=X, expand=True)
            
        btn_badge = tb.Button(frame_botones, text="Insignia Pro", bootstyle="outline-success",
                              command=lambda: mon_vista.renderizar_agradecimiento_discreto(self.f_docs_modulo))
        btn_badge.pack(side=LEFT, padx=3, fill=X, expand=True)

        estado_sim = {"donador": False}
        def toggle_sidebar():
            estado_sim["donador"] = not estado_sim["donador"]
            self._dibujar_info_usuario(donador_simulado=estado_sim["donador"])
            if estado_sim["donador"]:
                btn_sidebar.configure(bootstyle="success", text="Quitar IMG Sidebar")
            else:
                btn_sidebar.configure(bootstyle="outline-success", text="Simular IMG Sidebar")

        btn_sidebar = tb.Button(frame_botones, text="IMG Sidebar", bootstyle="outline-success", command=toggle_sidebar)
        btn_sidebar.pack(side=LEFT, padx=3, fill=X, expand=True)

        # --- NUEVO: Alternador de Mantenimiento en Tiempo Real ---
        def toggle_mantenimiento():
            # Si el código actual es el 'hub', leemos la tarjeta que se está visualizando
            cod = getattr(self, 'modulo_actual_cod', None)
            if cod not in self.catalogo:
                cod = getattr(self, 'modulo_viendo_en_hub', None)

            if not cod or cod not in self.catalogo:
                messagebox.showinfo("Aviso", "Selecciona una herramienta en el Hub primero.", parent=top)
                return
            
            bloqueados = self.licencia.setdefault("modulos_bloqueados", [])
            if cod in bloqueados:
                bloqueados.remove(cod)
                btn_mant.configure(bootstyle="outline-danger", text="Bloquear Módulo")
            else:
                bloqueados.append(cod)
                btn_mant.configure(bootstyle="danger", text="Restaurar Módulo")
            
            # Forzamos el redibujado de las tarjetas izquierdas y el panel derecho
            self._cargar_inicio()
            self._mostrar_detalle(cod)

        btn_mant = tb.Button(frame_botones, text="Bloquear Módulo", bootstyle="outline-danger", command=toggle_mantenimiento)
        btn_mant.pack(side=LEFT, padx=3, fill=X, expand=True)

    def actualizar_idioma_ui(self):
        self.chk_aprender.configure(text=i18n.t("sw_ayudas_visuales"))
        self.lbl_nav_titulo.configure(text=i18n.t("menu_navegacion"))
        self.btn_acerca.configure(text=f"ℹ️ {i18n.t('menu_ayuda')}")
        
        # Refrescar el botón toggle solo si el panel está visible
        if getattr(self, 'sidebar_visible', True):
            self.btn_toggle_sidebar.configure(text=i18n.t("btn_ocultar_panel"))
        self.lbl_version.configure(text=i18n.t("lbl_version_hub", version=VERSION_LAUNCHER))
        self.lbl_creditos.configure(text=i18n.t("lbl_creditos"))
        
        for data in self.botones_sidebar.values():
            texto_traducido = f"{data['icono']} {i18n.t(data['clave'])}"
            texto_final = texto_traducido if data['autorizado'] else f"🔒 {texto_traducido}"
            data['widget'].configure(text=texto_final)
            
        self._dibujar_info_usuario()
        self._definir_catalogo_modulos()

        # --- ACTUALIZACIÓN DINÁMICA DEL HEADER Y PANELES ---
        if hasattr(self, 'modulo_actual_cod'):
            cod = self.modulo_actual_cod
            if cod in self.catalogo:
                info = self.catalogo[cod]
                self.lbl_modulo_actual.configure(text=f"{info['titulo']} v{info['version']}")
                # Recargamos la vista del módulo para que el README se traduzca al instante
                self._mostrar_detalle(cod) 
            elif cod == "hub":
                self.lbl_modulo_actual.configure(text=i18n.t("lbl_directorio"))
                self._cargar_inicio()
            elif cod and cod.startswith("hub_grupo_"):
                # Si estamos dentro de un grupo filtrado, recargamos con ese filtro
                id_grupo = cod.replace("hub_grupo_", "")
                self._cargar_inicio(grupo_filtro=id_grupo)
            elif cod == "acerca":
                self.lbl_modulo_actual.configure(text=f"{i18n.t('menu_ayuda')} CyC Topografía")
                self._abrir_acerca_de()
                
        # Traducir el botón de apoyo en tiempo real
        if hasattr(self, 'lbl_apoyo') and self.lbl_apoyo.winfo_exists():
            self.lbl_apoyo.configure(text=f"☕ {i18n.t('lbl_apoyar_proyecto')}")

    def _limpiar_area_trabajo(self, titulo_modulo, cod_modulo=None):
        self.modulo_actual_cod = cod_modulo
        
        # Auto-traducción si es un módulo oficial del catálogo
        if cod_modulo in self.catalogo:
            info = self.catalogo[cod_modulo]
            titulo_final = f"{info['titulo']} v{info['version']}"
        else:
            titulo_final = titulo_modulo
            
        self.lbl_modulo_actual.configure(text=titulo_final)
        
        for widget in self.f_docs_modulo.winfo_children(): widget.destroy()
        for widget in self.frame_herramienta.winfo_children(): widget.destroy()

        def abrir_paypal(event):
            from monetizacion import servicio_paypal
            from i18.i18n_controlador import i18n
            hwid_usuario = self.licencia.get("hwid", "NO_HWID")
            estado_actual = self.licencia.get("estado", "BASICO")
            servicio_paypal.abrir_donacion(
                hwid=hwid_usuario, 
                origen="Banner Superior",
                modulo_origen=cod_modulo if cod_modulo else "Hub",
                version=VERSION_LAUNCHER,
                estado=estado_actual,
                idioma=i18n.get_idioma_actual().upper()
            ) 
        
        self.lbl_apoyo = ctk.CTkLabel(
            self.f_docs_modulo, 
            text=f"☕ {i18n.t('lbl_apoyar_proyecto')}", 
            font=('Segoe UI', 13, 'bold', 'underline'), 
            text_color=COLOR_ACENTO_PPAL, 
            cursor="hand2"
        )
        self.lbl_apoyo.pack(side=RIGHT, pady=10, padx=(10, 0))
        self.lbl_apoyo.bind("<Button-1>", abrir_paypal)

        # Renderizar logo institucional horizontal (Convive con el banner de monetización)
        try:
            ruta_logo_horiz = obtener_ruta_recurso("logo_horizontal.png") 
            img_h = Image.open(ruta_logo_horiz)
            ancho_h, alto_h = img_h.size
            alto_obj_h = 40 
            ancho_obj_h = int(alto_obj_h * (ancho_h / alto_h))
            
            logo_h_ctk = ctk.CTkImage(light_image=img_h, dark_image=img_h, size=(ancho_obj_h, alto_obj_h))
            self.lbl_logo_horizontal = ctk.CTkLabel(self.f_docs_modulo, text="", image=logo_h_ctk)
            
            # Verificamos si el panel ya estaba oculto para mostrar el logo inmediatamente
            if not getattr(self, 'sidebar_visible', True):
                self.lbl_logo_horizontal.pack(side=RIGHT, padx=20, pady=5)
        except Exception as e:
            self.lbl_logo_horizontal = None

    def _cargar_inicio(self, grupo_filtro=None):
        # 1. Determinar qué vamos a mostrar y qué título poner
        if grupo_filtro and grupo_filtro in self.grupos:
            info_grupo = self.grupos[grupo_filtro]
            titulo_header = f"{info_grupo['icono']} {i18n.t(info_grupo['clave_titulo'])}"
            # Filtramos el catálogo respetando el orden del grupo
            modulos_a_mostrar = {cod: self.catalogo[cod] for cod in info_grupo["modulos"] if cod in self.catalogo}
            self._limpiar_area_trabajo(titulo_header, f"hub_grupo_{grupo_filtro}")
        else:
            # Si no hay filtro (clic en Hub de Herramientas), mostramos todo
            titulo_header = i18n.t("lbl_directorio")
            modulos_a_mostrar = self.catalogo
            self._limpiar_area_trabajo(titulo_header, "hub")
        
        self.f_dashboard = ctk.CTkFrame(self.frame_herramienta, fg_color="transparent")
        self.f_dashboard.pack(fill=BOTH, expand=True)

        self.f_izq = ctk.CTkScrollableFrame(self.f_dashboard, width=380, fg_color="transparent", scrollbar_button_color="#d1d6d3", scrollbar_button_hover_color="#b0b5b2")
        self.f_izq.pack(side=LEFT, fill=Y, padx=(0, 20))

        ctk.CTkLabel(self.f_izq, text=f"{i18n.t('lbl_herramientas_instaladas')} ({len(modulos_a_mostrar)})", font=('Segoe UI', 14, 'bold'), text_color=COLOR_TEXTO_SEC).pack(anchor=W, pady=(0,15))

        self.tarjetas_ui = {}
        for cod, info in modulos_a_mostrar.items():
            self._crear_tarjeta_lista(cod, info)

        self.f_detalle = ctk.CTkFrame(self.f_dashboard, fg_color=COLOR_SURFACE, corner_radius=12, border_width=1, border_color=COLOR_BORDES)
        self.f_detalle.pack(side=LEFT, fill=BOTH, expand=True)

        # Autoseleccionar el primer módulo de la lista filtrada
        if modulos_a_mostrar:
            self._mostrar_detalle(list(modulos_a_mostrar.keys())[0])

    def _crear_tarjeta_lista(self, cod_modulo, info):
        bloqueado = cod_modulo in self.licencia.get("modulos_bloqueados", [])
        # La tarjeta SIEMPRE tiene el cursor de interacción
        f_tarjeta = ctk.CTkFrame(self.f_izq, fg_color=COLOR_SURFACE, corner_radius=10, border_width=1, border_color=COLOR_BORDES, cursor="hand2")
        f_tarjeta.pack(fill=X, pady=(0, 15), ipady=5)
        self.tarjetas_ui[cod_modulo] = f_tarjeta

        f_top = ctk.CTkFrame(f_tarjeta, fg_color="transparent")
        f_top.pack(fill=X, padx=15, pady=(15, 5))
        
        f_icon = ctk.CTkFrame(f_top, fg_color="#eaf3ee", corner_radius=6)
        f_icon.pack(side=LEFT)
        ctk.CTkLabel(f_icon, text=info["icono"], font=('Segoe UI', 16)).pack(padx=8, pady=4)
        
        ctk.CTkLabel(f_top, text=info["titulo"], font=('Segoe UI', 14, 'bold'), text_color=COLOR_TEXTO_MAIN).pack(side=LEFT, padx=10)
        
        status_color = "#ef4444" if bloqueado else COLOR_ACENTO_PPAL
        texto_estado = "MANTENIMIENTO" if bloqueado else i18n.t("lbl_activo")
        ctk.CTkLabel(f_top, text=texto_estado, font=('Segoe UI', 10, 'bold'), text_color=status_color).pack(side=RIGHT)

        ctk.CTkLabel(f_tarjeta, text=info["desc_corta"], font=('Segoe UI', 12), text_color=COLOR_TEXTO_SEC, wraplength=320, justify=LEFT).pack(fill=X, padx=15, pady=(0, 15))

        # SIEMPRE permitimos propagar el clic para leer el README
        def propagar_clic(event, cod=cod_modulo): self._mostrar_detalle(cod)
        f_tarjeta.bind("<Button-1>", propagar_clic)
        for child in f_tarjeta.winfo_children() + f_top.winfo_children() + f_icon.winfo_children():
            try: child.bind("<Button-1>", propagar_clic)
            except: pass

    def _mostrar_detalle(self, cod_modulo):
        self.modulo_viendo_en_hub = cod_modulo # <-- Guardamos en memoria la tarjeta que estamos viendo
        info = self.catalogo[cod_modulo]
        
        for cod, card in self.tarjetas_ui.items():
            if cod == cod_modulo:
                card.configure(border_color=COLOR_ACENTO_PPAL, border_width=2)
            else:
                card.configure(border_color=COLOR_BORDES, border_width=1)

        for widget in self.f_detalle.winfo_children(): widget.destroy()

        f_header = ctk.CTkFrame(self.f_detalle, fg_color="transparent")
        f_header.pack(fill=X, padx=40, pady=(40, 20))
        
        f_icon_bg = ctk.CTkFrame(f_header, fg_color=COLOR_ACENTO_PPAL, corner_radius=15)
        f_icon_bg.pack(side=LEFT)
        ctk.CTkLabel(f_icon_bg, text=info["icono"], font=('Segoe UI', 32), text_color="white").pack(padx=20, pady=10)

        f_titulos = ctk.CTkFrame(f_header, fg_color="transparent")
        f_titulos.pack(side=LEFT, padx=25, fill=X, expand=True)
        ctk.CTkLabel(f_titulos, text=info["titulo"], font=('Segoe UI', 28, 'bold'), text_color=COLOR_TEXTO_MAIN).pack(anchor=W)
        ctk.CTkLabel(f_titulos, text=f"Versión {info['version']} • Pipeline CyC", font=('Segoe UI', 13), text_color=COLOR_TEXTO_SEC).pack(anchor=W)

        # Metemos los botones DENTRO de la columna de los títulos (justo debajo del texto)
        f_botones = ctk.CTkFrame(f_titulos, fg_color="transparent")
        f_botones.pack(anchor=W, pady=(15, 0))

        txt_readme = ctk.CTkTextbox(self.f_detalle, wrap="word", fg_color="transparent", text_color=COLOR_TEXTO_MAIN)
        
        txt_readme._textbox.tag_config("h1", font=('Segoe UI', 18, 'bold'), foreground=COLOR_ACENTO_PPAL, spacing1=15, spacing3=10)
        txt_readme._textbox.tag_config("h2", font=('Segoe UI', 15, 'bold'), foreground=COLOR_TEXTO_MAIN, spacing1=12, spacing3=5)
        txt_readme._textbox.tag_config("h3", font=('Segoe UI', 13, 'bold'), foreground="#444444", spacing1=8, spacing3=5)
        txt_readme._textbox.tag_config("p", font=('Segoe UI', 12), spacing1=3, spacing3=3)
        txt_readme._textbox.tag_config("li", font=('Segoe UI', 12), lmargin1=20, lmargin2=35, spacing1=3, spacing3=3)
        txt_readme._textbox.tag_config("bold", font=('Segoe UI', 12, 'bold'))
        txt_readme._textbox.tag_config("code", font=('Consolas', 11), background="#e0e4e8", foreground="#d63384")

        estado_visor = {"doc_actual": "README.md"}

        def cargar_documento(archivo_base):
            txt_readme.configure(state="normal")
            txt_readme.delete("1.0", "end") 
            
            # 1. Intentar cargar la versión traducida (ej. README_en.md)
            idioma = i18n.get_idioma_actual().lower() # Retorna 'es', 'en' o 'pt'
            nombre_traducido = archivo_base.replace(".md", f"_{idioma}.md")
            
            ruta_relativa = os.path.join(cod_modulo, nombre_traducido)
            ruta_absoluta = obtener_ruta_recurso(ruta_relativa)
            
            # 2. Sistema de Respaldo (Fallback): Si no existe la traducción, usa el archivo original
            if not os.path.exists(ruta_absoluta):
                ruta_relativa = os.path.join(cod_modulo, archivo_base)
                ruta_absoluta = obtener_ruta_recurso(ruta_relativa)

            try:
                with open(ruta_absoluta, 'r', encoding='utf-8') as f:
                    for linea in f:
                        linea = linea.rstrip()
                        if linea.startswith('# '): txt_readme.insert("end", linea[2:] + "\n", "h1")
                        elif linea.startswith('## '): txt_readme.insert("end", linea[3:] + "\n", "h2")
                        elif linea.startswith('### '): txt_readme.insert("end", linea[4:] + "\n", "h3")
                        elif linea.startswith('* ') or linea.startswith('- '):
                            self._insertar_con_formato_inline(txt_readme, "• " + linea[2:], "li")
                        else:
                            self._insertar_con_formato_inline(txt_readme, linea, "p")
            except Exception as e:
                txt_readme.insert("end", f"No se encontró la documentación para este módulo.\n\n", "p")
                if archivo_base == "README.md":
                    txt_readme.insert("end", info["desc_larga"], "p")

            txt_readme.configure(state="disabled")

        def alternar_documento():
            if estado_visor["doc_actual"] == "README.md":
                estado_visor["doc_actual"] = "CHANGELOG.md"
                btn_doc_toggle.configure(text=i18n.t("btn_ver_readme"))
            else:
                estado_visor["doc_actual"] = "README.md"
                btn_doc_toggle.configure(text=i18n.t("btn_ver_changelog"))
            
            cargar_documento(estado_visor["doc_actual"])

        # Botón principal amarillo (Alineado primero a la izquierda)
        btn_abrir = ctk.CTkButton(f_botones, text=i18n.t("btn_abrir_herramienta"), command=info["comando"],
                                  fg_color="#ffc439", hover_color="#e5a822", text_color="#000000", font=('Segoe UI', 14, 'bold'), height=40)
                                  
        bloqueado = cod_modulo in self.licencia.get("modulos_bloqueados", [])
        if bloqueado:
            btn_abrir.configure(
                text=i18n.t("btn_mantenimiento"),
                fg_color="#ef4444", 
                hover_color="#dc2626",
                text_color="#facc15",
                command=lambda: messagebox.showwarning("Mantenimiento", i18n.t("msg_mantenimiento_desc"))
            )
            
        btn_abrir.pack(side=LEFT, padx=(0, 15))

        # Botón secundario de Changelog (Alineado a la derecha del botón abrir)
        texto_btn_doc = i18n.t("btn_ver_changelog") if estado_visor["doc_actual"] == "README.md" else i18n.t("btn_ver_readme")
        btn_doc_toggle = ctk.CTkButton(f_botones, text=texto_btn_doc, command=alternar_documento,
                                       fg_color="transparent", border_width=1, border_color=COLOR_BORDES, hover_color="#f0f2f1",
                                       text_color=COLOR_TEXTO_MAIN, font=('Segoe UI', 13, 'bold'), height=40)
        btn_doc_toggle.pack(side=LEFT)

        ctk.CTkFrame(self.f_detalle, height=1, fg_color=COLOR_BORDES).pack(fill=X, padx=40, pady=(10, 20)) 

        txt_readme.pack(fill=BOTH, expand=True, padx=40, pady=(0, 20))
        cargar_documento("README.md")

    def _abrir_linderos(self):
        self._limpiar_area_trabajo(f"Ajuste de Linderos v{V_LINDEROS}", "linderos")
        self.tab_linderos = TabAjusteLinderos(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_linderos.pack(fill=BOTH, expand=True)
        self.ctrl_linderos = ControladorLinderos(self.tab_linderos)

    def _abrir_gnss(self):
        self._limpiar_area_trabajo(f"Factores GNSS v{V_GNSS}", "gnss")
        self.tab_gnss = TabFactoresGNSS(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_gnss.pack(fill=BOTH, expand=True)
        self.ctrl_gnss = ControladorGNSS(self.tab_gnss)

    def _abrir_datalink(self):
        self._limpiar_area_trabajo(f"DataLink Converter v{V_DATALINK}", "datalink")
        self.tab_datalink = TabDataLink(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_datalink.pack(fill=BOTH, expand=True)
        self.ctrl_datalink = ControladorDataLink(self.tab_datalink)
    
    def _abrir_rinex(self):
        self._limpiar_area_trabajo(f"Orquestador de Descargas RINEX v{V_RINEX}", "rinex")
        self.tab_rinex = TabUnionRinex(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_rinex.pack(fill=BOTH, expand=True)
        self.ctrl_rinex = ControladorRinex(self.tab_rinex)

    def _abrir_postproceso(self):
        self._limpiar_area_trabajo(f"Motor de Postproceso GNSS v{V_POSTPROCESO}", "postproceso")
        self.tab_post = TabPostproceso(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_post.pack(fill=BOTH, expand=True)
        self.ctrl_post = ControladorPostproceso(self.tab_post)

    def _abrir_conversiones(self):
        self._limpiar_area_trabajo(f"Conversor Geodésico v{V_CONVERSIONES}", "conversiones")
        self.tab_conversiones = TabConversor(self.frame_herramienta, self.var_modo_aprendizaje)
        self.tab_conversiones.pack(fill=BOTH, expand=True)
        self.ctrl_conversiones = ControladorConversor(self.tab_conversiones)

    def _abrir_presupuestos(self):
        self._limpiar_area_trabajo(f"{i18n.t('cat_presupuestos_titulo')} v{V_PRESUPUESTOS}", "presupuestos")
        
        # Instanciación limpia a través de la Fachada/Puente
        self.app_presupuestos = PresupuestosApp(
            parent_frame=self.frame_herramienta, 
            var_aprendizaje=self.var_modo_aprendizaje
        )
        montaje_ok = self.app_presupuestos.montar()
        if not montaje_ok:
            detalle = getattr(self.app_presupuestos, "ultimo_error", "") or "Revisa el log local del modulo para mas detalle."
            messagebox.showerror(
                "Error al abrir Presupuestos",
                f"No se pudo iniciar el modulo de Presupuestos.\n\nDetalle tecnico:\n{detalle}"
            )

    def _abrir_acerca_de(self):
        self._limpiar_area_trabajo(f"{i18n.t('menu_ayuda')} CyC Topografía", "acerca")

        f_acerca = ctk.CTkFrame(self.frame_herramienta, fg_color=COLOR_SURFACE, corner_radius=12, border_width=1, border_color=COLOR_BORDES)
        f_acerca.pack(fill=BOTH, expand=True, padx=40, pady=20)

        f_inner = ctk.CTkFrame(f_acerca, fg_color="transparent")
        f_inner.pack(fill=BOTH, expand=True, padx=80, pady=50)

        estado_actual = self.licencia.get("estado", "BASICO")
        
        # Textos dinámicos según el estado de la licencia traducidos
        if estado_actual == "EVALUACION":
            info_estado = i18n.t("acerca_evaluacion")
        elif estado_actual in ["DONADOR_PRO", "ADMIN"]:
            info_estado = i18n.t("acerca_pro")
        else:
            info_estado = i18n.t("acerca_basico")

        texto_acerca = f"{info_estado}\n\n{i18n.t('acerca_filosofia')}"

        lbl_texto = ctk.CTkLabel(
            f_inner, text=texto_acerca, font=('Segoe UI', 15), text_color=COLOR_TEXTO_MAIN, justify=LEFT, wraplength=850
        )
        lbl_texto.pack(anchor=W, pady=(0, 40))

        # Renderizar la caja de donación (Limpia)
        f_donacion = ctk.CTkFrame(f_inner, fg_color="#eaf3ee", corner_radius=8)
        f_donacion.pack(fill=X, pady=10, ipady=15)

        ctk.CTkLabel(f_donacion, text=i18n.t("acerca_donacion_titulo"), font=('Segoe UI', 16, 'bold'), text_color=COLOR_ACENTO_PPAL).pack(pady=(15, 5))
        
        if estado_actual in ["DONADOR_PRO", "ADMIN"]:
            texto_apoyo = i18n.t("acerca_donacion_apoyo_pro")
            texto_boton = i18n.t("acerca_donacion_btn_pro")
        else:
            texto_apoyo = i18n.t("acerca_donacion_apoyo_basico")
            texto_boton = i18n.t("acerca_donacion_btn_basico")

        ctk.CTkLabel(f_donacion, text=texto_apoyo, font=('Segoe UI', 13), text_color=COLOR_TEXTO_MAIN).pack(pady=(0, 15))

        # --- BOTÓN DE PAYPAL ---
        hwid_usuario = self.licencia.get("hwid", "NO_HWID")
        
        def al_donar():
            from monetizacion import servicio_paypal
            from i18.i18n_controlador import i18n
            
            servicio_paypal.abrir_donacion(
                hwid=hwid_usuario, 
                origen="Pestaña Acerca De",
                modulo_origen="Hub Principal",
                version=VERSION_LAUNCHER,
                estado=estado_actual,
                idioma=i18n.get_idioma_actual().upper()
            )
            
        btn_donar = ctk.CTkButton(
            f_donacion, text=texto_boton, command=al_donar, 
            fg_color="#ffc439", hover_color="#e5a822", text_color="#000000", 
            font=('Segoe UI', 14, 'bold'), corner_radius=6, height=40
        )
        btn_donar.pack(pady=(5, 10))

    def ir_a_postproceso(self): self._abrir_postproceso()
    def ir_a_descargas(self): self._abrir_rinex()

    def _mostrar_documento(self, modulo, archivo):
        import re 
        ruta_relativa = os.path.join(modulo, archivo) if modulo else archivo
        ruta_absoluta = obtener_ruta_recurso(ruta_relativa)
        
        if not os.path.exists(ruta_absoluta):
            messagebox.showinfo("No encontrado", f"No se encontró el archivo:\n{ruta_absoluta}")
            return
            
        top = tb.Toplevel(self)
        top.title(f"{archivo} - Módulo: {modulo}" if modulo else f"{archivo} - CyC Hub")
        top.geometry("750x650")
        top.attributes('-topmost', True)
        
        txt = tb.Text(top, wrap=WORD, padx=25, pady=25, borderwidth=0, highlightthickness=0)
        scroll = tb.Scrollbar(top, command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        
        scroll.pack(side=RIGHT, fill=Y)
        txt.pack(side=LEFT, fill=BOTH, expand=True)
        
        txt.tag_config("h1", font=('Arial', 18, 'bold'), foreground=COLOR_ACENTO_PPAL, spacing1=15, spacing3=10)
        txt.tag_config("h2", font=('Arial', 14, 'bold'), foreground="#222", spacing1=12, spacing3=5)
        txt.tag_config("h3", font=('Arial', 12, 'bold'), foreground="#444", spacing1=8, spacing3=5)
        txt.tag_config("p", font=('Arial', 10), spacing1=3, spacing3=3)
        txt.tag_config("li", font=('Arial', 10), lmargin1=20, lmargin2=35, spacing1=3, spacing3=3)
        txt.tag_config("bold", font=('Arial', 10, 'bold'))
        txt.tag_config("code", font=('Consolas', 9), background="#e0e0e0", foreground="#d63384")

        try:
            with open(ruta_absoluta, 'r', encoding='utf-8') as f:
                for linea in f:
                    linea = linea.rstrip()
                    if linea.startswith('# '): txt.insert(END, linea[2:] + "\n", "h1")
                    elif linea.startswith('## '): txt.insert(END, linea[3:] + "\n", "h2")
                    elif linea.startswith('### '): txt.insert(END, linea[4:] + "\n", "h3")
                    elif linea.startswith('* ') or linea.startswith('- '):
                        self._insertar_con_formato_inline(txt, "• " + linea[2:], "li")
                    else:
                        self._insertar_con_formato_inline(txt, linea, "p")
        except Exception as e:
            txt.insert(END, f"Error al leer el archivo:\n{e}", "p")
            
        txt.config(state=DISABLED)

    def _insertar_con_formato_inline(self, widget_text, texto, tag_base):
        import re
        partes = re.split(r'(\*\*.*?\*\*|`.*?`)', texto)
        for parte in partes:
            if parte.startswith('**') and parte.endswith('**'):
                widget_text.insert(END, parte[2:-2], (tag_base, "bold"))
            elif parte.startswith('`') and parte.endswith('`'):
                widget_text.insert(END, parte[1:-1], (tag_base, "code"))
            else:
                widget_text.insert(END, parte, tag_base)
        widget_text.insert(END, "\n", tag_base)

    def _bloquear_suite_entera(self, mensaje, hwid):
        top = tb.Toplevel(self)
        top.title("Licencia Requerida")
        top.geometry("450x260")
        top.attributes('-topmost', True) 
        top.protocol("WM_DELETE_WINDOW", self.destroy) 

        tb.Label(top, text="⚠️ ACCESO DENEGADO", font=('Arial', 12, 'bold'), bootstyle="danger").pack(pady=10)
        tb.Label(top, text=mensaje, justify=CENTER, wraplength=400).pack(pady=10)
        
        hwid_txt = tb.Text(top, height=2, width=45, font=('Consolas', 10))
        hwid_txt.pack(pady=5)
        hwid_txt.insert(END, hwid)
        hwid_txt.config(state=DISABLED)
        
        def copiar():
            self.clipboard_clear()
            self.clipboard_append(hwid)
            messagebox.showinfo("Copiado", "HWID copiado.", parent=top)
            
        tb.Button(top, text="📋 Copiar HWID", bootstyle="danger", command=copiar).pack(pady=15)
