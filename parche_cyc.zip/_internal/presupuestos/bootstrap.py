# presupuestos/bootstrap.py
import logging
import os
import traceback
from .core.database_manager import GestorBaseDatos
from .ui.main_view import VistaPresupuestosPrincipal
from .controlador_central import ControladorPresupuestos

logger = logging.getLogger(__name__)

class PresupuestosApp:
    """
    PUNTO DE ENTRADA ÚNICO (Bootstrap).
    El Hub principal interactúa solo con esta clase para mantener el aislamiento estructural.
    """
    def __init__(self, parent_frame, var_aprendizaje, config_hub=None):
        self.parent = parent_frame
        self.var_aprendizaje = var_aprendizaje
        self.config = config_hub or {}
        
        # Referencias internas
        self._db = None
        self._vista = None
        self._controlador = None
        self.ultimo_error = ""
        
        logger.info("Módulo de Presupuestos instanciado (v260424.1620)")

    def _obtener_ruta_log_error(self):
        base_usuario = (
            os.environ.get("LOCALAPPDATA")
            or os.environ.get("APPDATA")
            or os.path.join(os.path.expanduser("~"), "AppData", "Local")
        )
        ruta_logs = os.path.join(base_usuario, "CyC_Suite", "presupuestos", "logs")
        os.makedirs(ruta_logs, exist_ok=True)
        return os.path.join(ruta_logs, "presupuestos_error.log")

    def _registrar_error_critico(self, detalle_error):
        try:
            ruta_log = self._obtener_ruta_log_error()
            with open(ruta_log, "a", encoding="utf-8") as archivo_log:
                archivo_log.write("\n" + "=" * 80 + "\n")
                archivo_log.write(detalle_error)
                if not detalle_error.endswith("\n"):
                    archivo_log.write("\n")
        except Exception:
            logger.exception("No se pudo escribir el log de error de Presupuestos.")

    def montar(self):
        """
        Construye, ensambla y empaqueta el módulo dentro del parent_frame.
        Retorna True si el montaje fue exitoso, False si hubo errores.
        """
        try:
            # 1. Levantar conexión SQLite (Gestor Agnóstico)
            self._db = GestorBaseDatos()
            self._db.inicializar_esquemas()

            # 2. Instanciar la Fachada de UI y anclarla al Hub Principal
            self._vista = VistaPresupuestosPrincipal(self.parent, self.var_aprendizaje)
            
            # 3. Conectar el Orquestador Central inyectando Vista y DB
            self._controlador = ControladorPresupuestos(self._vista, self._db)
            
            logger.info("Módulo de Presupuestos montado y conectado exitosamente.")
            return True
            
        except Exception as e:
            detalle_error = traceback.format_exc()
            self.ultimo_error = str(e)
            logger.exception("Error crítico al montar el módulo de presupuestos.")
            self._registrar_error_critico(detalle_error)
            return False

    def desmontar(self):
        """
        Destrucción segura para liberar memoria, apagar observadores i18n
        y evitar excepciones de Ghost Widgets.
        """
        if self._vista and self._vista.winfo_exists():
            self._vista.destroy()
            self._vista = None
            
        self._controlador = None
        # En una arquitectura estricta, aquí también se cierra la DB si no se comparte:
        # Si GestorBaseDatos tuviese un cerrar_conexion(), se llamaría aquí.
        
        logger.info("Módulo de Presupuestos desmontado de forma segura.")
