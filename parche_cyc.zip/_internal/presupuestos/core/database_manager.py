# presupuestos/core/database_manager.py
import sqlite3
import os
import sys
import logging
import json
import shutil
from ..constants import DB_NAME, DB_DIR

logger = logging.getLogger(__name__)

class GestorBaseDatos:
    def __init__(self):
        self.modo_basico = False
        self.fusion_pendiente = False
        self.archivos_a_fusionar = []
        self.archivo_config = ""
        self.db_path = self._obtener_ruta_db()

    def _obtener_directorio_datos(self):
        if getattr(sys, "frozen", False):
            base_usuario = (
                os.environ.get("LOCALAPPDATA")
                or os.environ.get("APPDATA")
                or os.path.join(os.path.expanduser("~"), "AppData", "Local")
            )
            ruta_datos = os.path.join(base_usuario, "CyC_Suite", "presupuestos", DB_DIR)
        else:
            ruta_base = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
            ruta_datos = os.path.join(ruta_base, DB_DIR)

        os.makedirs(ruta_datos, exist_ok=True)
        return ruta_datos

    def _obtener_ruta_db(self):
        ruta_completa_dir = self._obtener_directorio_datos()
        ruta_por_defecto = os.path.join(ruta_completa_dir, DB_NAME)
        self.archivo_config = os.path.join(ruta_completa_dir, "db_config.json")
        logger.info(f"Directorio de datos de Presupuestos: {ruta_completa_dir}")
        
        # --- 1. VERIFICACIÓN DE SEGURIDAD ---
        try:
            from seguridad.seguridad import verificar_licencia
            licencia = verificar_licencia()
            estado_licencia = licencia.get("estado", "BASICO")
        except Exception as e:
            logger.error(f"Falla al leer licencia en BD: {e}")
            estado_licencia = "BASICO"

        import tempfile
        import glob
        from datetime import datetime
        carpeta_sesiones = os.path.join(tempfile.gettempdir(), ".cyc_presupuestos_sesiones")

        if estado_licencia == "BASICO":
            self.modo_basico = True
            if not os.path.exists(carpeta_sesiones):
                os.makedirs(carpeta_sesiones)
            
            # Crear DB nueva oculta para ESTA sesión
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ruta_oculta = os.path.join(carpeta_sesiones, f"sesion_{timestamp}.tmp")
            logger.info(f"Modo Básico: Iniciando sesión aislada en {ruta_oculta}")
            return ruta_oculta
            
        # --- 2. MODO PREMIUM: Verificar si hay sesiones pendientes por fusionar ---
        if os.path.exists(carpeta_sesiones):
            sesiones_pendientes = glob.glob(os.path.join(carpeta_sesiones, "*.tmp"))
            if sesiones_pendientes:
                self.fusion_pendiente = True
                self.archivos_a_fusionar = sesiones_pendientes

        # --- 3. MODO PREMIUM O EVALUACIÓN ACTIVA: Memoria de Base de Datos ---
        if os.path.exists(self.archivo_config):
            try:
                with open(self.archivo_config, 'r') as f:
                    config = json.load(f)
                    ruta_guardada = config.get("ultima_bd", "")
                    if ruta_guardada and os.path.exists(ruta_guardada):
                        return ruta_guardada
            except Exception:
                pass
        return ruta_por_defecto

    def respaldar_bd(self, ruta_destino):
        try:
            shutil.copy2(self.db_path, ruta_destino)
            return True, "Respaldo creado exitosamente."
        except Exception as e:
            return False, f"Error al respaldar: {str(e)}"

    def cambiar_bd_activa(self, nueva_ruta):
        try:
            self.db_path = nueva_ruta
            os.makedirs(os.path.dirname(self.archivo_config), exist_ok=True)
            with open(self.archivo_config, 'w') as f:
                json.dump({"ultima_bd": nueva_ruta}, f)
            self.inicializar_esquemas() # Verifica y migra automáticamente
            return True, "Base de datos conectada exitosamente."
        except Exception as e:
            return False, f"Error al conectar BD: {str(e)}"

    def conectar(self):
        return sqlite3.connect(self.db_path)

    def inicializar_esquemas(self):
        """Crea el esquema relacional normalizado (ERP)."""
        try:
            with self.conectar() as conn:
                cursor = conn.cursor()
                # Función de Migración Inteligente (Lee estructura actual y actualiza si es antigua)
                def asegurar_columna(tabla, columna, definicion):
                    cursor.execute(f"PRAGMA table_info({tabla})")
                    columnas_existentes = [row[1] for row in cursor.fetchall()]
                    if columna not in columnas_existentes:
                        cursor.execute(f"ALTER TABLE {tabla} ADD COLUMN {columna} {definicion}")

                cursor.execute('CREATE TABLE IF NOT EXISTS Clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_comercial TEXT NOT NULL, razon_social TEXT, rfc TEXT, telefono TEXT, email TEXT)')
                asegurar_columna('Clientes', 'representante_legal', 'TEXT')
                
                cursor.execute('CREATE TABLE IF NOT EXISTS Proyectos (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre_proyecto TEXT NOT NULL, cliente_id INTEGER, ubicacion TEXT, fecha TEXT NOT NULL, p_indirectos REAL DEFAULT 15.0, p_financiamiento REAL DEFAULT 1.5, p_utilidad REAL DEFAULT 10.0, p_cargos_adic REAL DEFAULT 0.5, FOREIGN KEY(cliente_id) REFERENCES Clientes(id) ON DELETE RESTRICT)')
                asegurar_columna('Proyectos', 'ubicacion', 'TEXT')
                cursor.execute('CREATE TABLE IF NOT EXISTS Insumos (id INTEGER PRIMARY KEY AUTOINCREMENT, clave TEXT UNIQUE NOT NULL, descripcion TEXT NOT NULL, unidad TEXT NOT NULL, costo_base REAL NOT NULL, tipo INTEGER NOT NULL)')
                cursor.execute('CREATE TABLE IF NOT EXISTS Conceptos (id INTEGER PRIMARY KEY AUTOINCREMENT, clave_concepto TEXT UNIQUE NOT NULL, descripcion TEXT NOT NULL, unidad TEXT NOT NULL)')
                cursor.execute('CREATE TABLE IF NOT EXISTS APU_Detalle (id INTEGER PRIMARY KEY AUTOINCREMENT, concepto_id INTEGER, insumo_id INTEGER, rendimiento REAL NOT NULL, FOREIGN KEY(concepto_id) REFERENCES Conceptos(id) ON DELETE CASCADE, FOREIGN KEY(insumo_id) REFERENCES Insumos(id) ON DELETE RESTRICT)')
                cursor.execute('CREATE TABLE IF NOT EXISTS Presupuesto_Detalle (id INTEGER PRIMARY KEY AUTOINCREMENT, proyecto_id INTEGER, concepto_id INTEGER, partida TEXT DEFAULT "1. PARTIDA GENERAL", subpartida TEXT DEFAULT "", volumen REAL NOT NULL, FOREIGN KEY(proyecto_id) REFERENCES Proyectos(id) ON DELETE CASCADE, FOREIGN KEY(concepto_id) REFERENCES Conceptos(id) ON DELETE RESTRICT)')
                
                # --- NUEVA TABLA: EMPRESAS PROPIAS (EMISORAS) ---
                cursor.execute('CREATE TABLE IF NOT EXISTS Empresas_Propias (id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, rfc TEXT, direccion TEXT, telefono TEXT, email TEXT, web TEXT)')
                
                # Sembrado inicial de empresas operativas
                cursor.execute('SELECT COUNT(*) FROM Empresas_Propias')
                if cursor.fetchone()[0] == 0:
                    empresas_base = [
                        ("CyC Topografía", "", "", "", "", ""),
                        ("Punto Vértice", "", "", "", "", ""),
                        ("Latitud 20", "", "", "", "", "")
                    ]
                    cursor.executemany('INSERT INTO Empresas_Propias (nombre, rfc, direccion, telefono, email, web) VALUES (?, ?, ?, ?, ?, ?)', empresas_base)
                
                conn.commit()
            logger.info("Esquemas de base de datos validados correctamente.")
        except Exception as e:
            logger.error(f"Error crítico al inicializar esquemas DB: {e}")

    def fusionar_bases_de_datos(self, ruta_destino):
        """Combina las bases de datos de sesión aislada en una sola manteniendo la integridad referencial (ERP)."""
        import sqlite3
        import os
        
        # 1. Preparar la BD Maestra destino
        bd_destino = sqlite3.connect(ruta_destino)
        cursor_dest = bd_destino.cursor()
        
        # Crear estructura usando el propio método de la clase
        old_path = self.db_path
        self.db_path = ruta_destino
        self.inicializar_esquemas()
        self.db_path = old_path

        # 2. Extraer, mapear e insertar cada fragmento
        for ruta_tmp in self.archivos_a_fusionar:
            try:
                bd_origen = sqlite3.connect(ruta_tmp)
                cur_orig = bd_origen.cursor()
                
                map_clientes, map_proyectos, map_conceptos, map_insumos = {}, {}, {}, {}

                # A. Migrar Clientes
                cur_orig.execute("SELECT * FROM Clientes")
                for row in cur_orig.fetchall():
                    cursor_dest.execute("INSERT INTO Clientes (nombre_comercial, razon_social, rfc, telefono, email, representante_legal) VALUES (?, ?, ?, ?, ?, ?)", row[1:])
                    map_clientes[row[0]] = cursor_dest.lastrowid

                # B. Migrar Proyectos (Re-escribiendo ID del cliente)
                cur_orig.execute("SELECT * FROM Proyectos")
                for row in cur_orig.fetchall():
                    nuevo_cliente_id = map_clientes.get(row[2])
                    cursor_dest.execute("INSERT INTO Proyectos (nombre_proyecto, cliente_id, ubicacion, fecha, p_indirectos, p_financiamiento, p_utilidad, p_cargos_adic) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (row[1], nuevo_cliente_id, row[3], row[4], row[5], row[6], row[7], row[8]))
                    map_proyectos[row[0]] = cursor_dest.lastrowid

                # C. Migrar Insumos (Omitiendo duplicados por clave maestra)
                cur_orig.execute("SELECT * FROM Insumos")
                for row in cur_orig.fetchall():
                    cursor_dest.execute("SELECT id FROM Insumos WHERE clave=?", (row[1],))
                    res = cursor_dest.fetchone()
                    if res: map_insumos[row[0]] = res[0]
                    else:
                        cursor_dest.execute("INSERT INTO Insumos (clave, descripcion, unidad, costo_base, tipo) VALUES (?, ?, ?, ?, ?)", row[1:])
                        map_insumos[row[0]] = cursor_dest.lastrowid

                # D. Migrar Conceptos (Omitiendo duplicados por clave maestra)
                cur_orig.execute("SELECT * FROM Conceptos")
                for row in cur_orig.fetchall():
                    cursor_dest.execute("SELECT id FROM Conceptos WHERE clave_concepto=?", (row[1],))
                    res = cursor_dest.fetchone()
                    if res: map_conceptos[row[0]] = res[0]
                    else:
                        cursor_dest.execute("INSERT INTO Conceptos (clave_concepto, descripcion, unidad) VALUES (?, ?, ?)", row[1:])
                        map_conceptos[row[0]] = cursor_dest.lastrowid

                # E. Migrar Matrices APU_Detalle (Re-escribiendo IDs de insumos y conceptos)
                cur_orig.execute("SELECT * FROM APU_Detalle")
                for row in cur_orig.fetchall():
                    nuevo_concepto = map_conceptos.get(row[1])
                    nuevo_insumo = map_insumos.get(row[2])
                    if nuevo_concepto and nuevo_insumo:
                        cursor_dest.execute("INSERT INTO APU_Detalle (concepto_id, insumo_id, rendimiento) VALUES (?, ?, ?)", (nuevo_concepto, nuevo_insumo, row[3]))

                # F. Migrar Presupuesto_Detalle (Volúmenes y Subpartidas)
                cur_orig.execute("SELECT * FROM Presupuesto_Detalle")
                for row in cur_orig.fetchall():
                    nuevo_proy = map_proyectos.get(row[1])
                    nuevo_concepto = map_conceptos.get(row[2])
                    if nuevo_proy and nuevo_concepto:
                        cursor_dest.execute("INSERT INTO Presupuesto_Detalle (proyecto_id, concepto_id, partida, subpartida, volumen) VALUES (?, ?, ?, ?, ?)", (nuevo_proy, nuevo_concepto, row[3], row[4], row[5]))

                bd_destino.commit()
                bd_origen.close()
                os.remove(ruta_tmp) # Destruir fragmento tras fusión exitosa
            except Exception as e:
                logger.error(f"Error fusionando fragmento {ruta_tmp}: {e}")

        bd_destino.close()
        self.fusion_pendiente = False
        self.archivos_a_fusionar = []
        return True, "Todas tus sesiones anteriores se han unificado correctamente."
