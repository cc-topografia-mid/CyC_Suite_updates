# Manifiesto del paquete `parche_cyc_acumulativo_20260707_2352.zip`

- Tipo: parche acumulativo
- Generado: 2026-07-07T23:52:04

## Parches de origen

- `parche_cyc_20260704_2023.zip`
- `parche_cyc_20260704_2211.zip`
- `parche_cyc_20260704_2352.zip`
- `parche_cyc_20260707_2346.zip`

## Archivos finales incluidos

- `_internal/CHANGELOG.MD` (18151 bytes)
- `_internal/cyc_updater.pyd` (957440 bytes)
- `_internal/hub_principal.pyd` (1072640 bytes)
- `_internal/i18/__init__.py` (0 bytes)
- `_internal/i18/idiomas/en/main.json` (5569 bytes)
- `_internal/i18/idiomas/es/main.json` (5839 bytes)
- `_internal/i18/idiomas/pt/main.json` (5908 bytes)
- `_internal/linderos/CHANGELOG.md` (17052 bytes)
- `_internal/linderos/__init__.py` (0 bytes)
- `_internal/linderos/controlador.pyd` (981504 bytes)
- `_internal/monetizacion/__init__.py` (0 bytes)
- `_internal/monetizacion/controlador.pyd` (743936 bytes)
- `_internal/monetizacion/vista.pyd` (753664 bytes)
- `_internal/postproceso/CHANGELOG.MD` (90310 bytes)
- `_internal/postproceso/__init__.py` (0 bytes)
- `_internal/postproceso/catalogo_ciclo_fix.pyd` (863744 bytes)
- `_internal/postproceso/controlador.pyd` (2425344 bytes)
- `_internal/postproceso/reporte_v1_secciones.pyd` (861184 bytes)
- `_internal/postproceso/reporteador_pdf.pyd` (1112064 bytes)
- `_internal/postproceso/reporteador_pdf_v2.pyd` (903168 bytes)
- `_internal/postproceso/repositorio_conocimiento.pyd` (778752 bytes)
- `_internal/postproceso/tema_reportes.pyd` (740864 bytes)
- `_internal/postproceso/vista.pyd` (1313280 bytes)
- `_internal/rinex/CHANGELOG.md` (17655 bytes)
- `_internal/rinex/__init__.py` (0 bytes)
- `_internal/rinex/controlador.pyd` (902656 bytes)
- `_internal/seguridad/__init__.py` (0 bytes)
- `_internal/seguridad/seguridad.pyd` (917504 bytes)
- `_internal/seguridad/seguridad.pyd.terabox.uploading.cfg` (740 bytes)
- `_internal/telemetria/__init__.py` (667 bytes)
- `_internal/telemetria/__init__.py.terabox.uploading.cfg` (733 bytes)
- `_internal/telemetria/cliente.pyd` (819712 bytes)
- `_internal/telemetria/config.pyd` (753152 bytes)
- `_internal/telemetria/configurar_supabase.pyd` (739328 bytes)
- `_internal/telemetria/exportar_reporte.pyd` (768512 bytes)
- `_internal/versiones.pyd` (743936 bytes)
