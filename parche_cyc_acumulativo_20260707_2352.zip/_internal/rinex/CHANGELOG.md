# 📜 Changelog - Orquestador Descargas GNSS (CyC Topografía Suite)

## [260626.0716] - 2026-06-26

### Añadido
- **Bloque 4 de alineación MVC:** La vista del Asistente RINEX GNSS queda preparada para emitir eventos de interfaz mientras el controlador decide acceso, catálogo y acciones externas.

### Cambiado
- **Versión centralizada de sesión:** El módulo RINEX toma ahora su versión activa desde `versiones.py` con el identificador `260626.0716`.
- **Catálogo de estaciones:** La lista de estaciones RGNA deja de consultarse desde la vista; el controlador la obtiene desde el modelo y la inyecta en el control visual.
- **Asistente manual INEGI:** El cálculo de nombres oficiales pasa al controlador; la vista sólo muestra el texto resultante.
- **Monetización no bloqueante:** El Asistente RINEX GNSS deja de condicionar su ejecución al estado `BASICO`/`Donador`; el botón principal siempre permite iniciar el flujo técnico y el controlador sólo notifica eventos pasivos al sistema de monetización.

### Corregido
- **Dependencias cruzadas en la vista:** Se eliminan imports directos de monetización, modelo RINEX y navegador web desde `vista.py`, reduciendo acoplamiento y preparando una internacionalización futura más limpia.
- **Bloqueo comercial eliminado:** Se retira la compuerta `Requiere Pro` del flujo activo del Asistente RINEX GNSS conforme a la política documentada: la licencia reconoce estados e informa banners, pero no bloquea herramientas, descargas, cálculos ni flujos de trabajo.

## [260625.1813] - 2026-06-25

### Añadido
- **Inicio de migración visual a la guía CyC:** Se incorporan tokens de paleta oficial en la vista del Asistente RINEX GNSS para preparar la estandarización transversal de la interfaz.
- **Versión centralizada de sesión:** El módulo RINEX toma ahora su versión activa desde `versiones.py` con el identificador `260625.1813`.

### Cambiado
- **Paleta de acentos:** Los controles principales pasan a usar el verde oficial `#1A7B3E` y el amarillo `#FFC439` para acciones restringidas, evitando variantes cromáticas no definidas por la guía.
- **Jerarquía operativa inicial:** La columna de configuración, Rover, servidor y productos queda priorizada a la izquierda; metadatos, ayuda y log quedan a la derecha como zona de resultados/proceso.
- **Estructura 50/50 del flujo principal:** El cuerpo del Asistente RINEX GNSS usa ahora columnas uniformes por `grid`, con configuración/insumos a la izquierda y metadatos/log a la derecha.
- **Ayuda permanente compacta:** El texto descriptivo extenso se reduce a una guía breve para no competir visualmente con los campos operativos ni con el registro técnico.
- **Antenas ATX:** La interfaz ya identifica correctamente el producto de antenas como `igs20.atx`, consistente con el motor de descarga.

### Corregido
- **Acentos fuera de guía:** Se elimina el rojo de la acción principal de unión/descarga y se reemplazan controles secundarios grises por variantes neutrales con borde o texto verde.
- **Estados de advertencia:** Las advertencias de rango horario dejan de depender de texto rojo y se muestran con semántica neutral/accionable.
- **Ajuste responsivo inicial:** El panel de configuración conserva scroll local y el log técnico crece dentro de su columna para reducir ocultamientos en ventanas de menor altura.

## [260623.0100] - 2026-06-23

### Añadido
- **Documentación funcional actualizada:** Los README en español, inglés y portugués fueron alineados con el estado operativo actual del módulo, incluyendo SFTP/FTP INEGI, IONEX, BRDC, SP3, CLK, ATX, sidecar `_cyc.json` y puente hacia Postproceso GNSS.
- **Referencia explícita al flujo Asistente RINEX GNSS:** La documentación describe ahora el módulo como asistente integral de carga, descarga, validación, unificación conservadora y preparación de insumos para postproceso.

### Cambiado
- **Versión de funciones:** Se actualiza `VERSION_ORQUESTADOR` a `260623.0100`.
- **Descripción operativa del módulo:** Se sustituye la visión antigua centrada sólo en "orquestador de descargas" por una descripción más precisa del flujo actual: análisis de Rover, selección de servidor INEGI, descarga de productos auxiliares, validación IONEX, persistencia en sidecar y entrega al pipeline.
- **Mensajes técnicos de documentación:** Los entregables y capacidades se reorganizan para diferenciar observación RINEX, navegación clásica, navegación combinada BRDC, efemérides precisas, relojes, antenas y mapas ionosféricos.

### Corregido
- **Desfase documental de versión:** Los README todavía reportaban `v260417.0802`; ahora quedan sincronizados con la versión funcional actual.
- **Omisión de productos ionosféricos:** La documentación ya no omite el soporte de descarga y validación de mapas IONEX.
- **Omisión de servidor INEGI moderno:** La documentación ahora refleja que el nuevo SFTP INEGI es la opción principal y que el FTP antiguo opera como respaldo.

## [260614.1230] - 2026-06-14

### Añadido
- **Descarga automática de mapas IONEX:** El Asistente RINEX GNSS puede obtener productos ionosféricos oficiales por fecha y DOY, priorizando el mapa final CODE desde los servidores públicos CODE/AIUB e IGN.
- **Validación técnica previa:** Los productos descargados se descomprimen y verifican por versión, cabecera, cobertura temporal, intervalo, tamaño y hash SHA-256 antes de quedar disponibles para postproceso.
- **Trazabilidad en sidecar y Pipeline:** `_cyc.json` conserva la ruta IONEX y sus metadatos auditables; el Pipeline entrega el archivo automáticamente al Motor de Postproceso GNSS.
- **Panel derecho desplazable:** La configuración del asistente incorpora desplazamiento vertical para conservar acceso a todos los controles en ventanas de menor altura.

### Cambiado
- **Carga RINEX prioritaria:** El selector del archivo Rover aparece ahora como el primer bloque visible, con lista compacta y acciones `Cargar RINEX` y `Limpiar` claramente disponibles.
- **Composición según modo:** El modo automático ordena Rover, servidores y opciones; la unión manual muestra primero los archivos y después el asistente de nombres INEGI.

### Corregido
- **Respuestas web no utilizables:** Las páginas HTML de autenticación o archivos truncados ya no pueden confundirse con un producto IONEX válido.

## [260607.1000] - 2026-06-07

### Añadido
- **Identidad de herramienta actualizada**: La interfaz adopta el nombre operativo **Asistente RINEX GNSS**, manteniendo compatibilidad con el flujo existente de descarga, carga y unión de archivos RINEX.
- **Selector de servidor INEGI**: Se integró un `Combobox` para elegir entre el **Nuevo SFTP INEGI** y el **Antiguo FTP INEGI**. El servidor nuevo queda como opción predeterminada.
- **Nuevo servidor SFTP RGNA**: Se añadieron las credenciales oficiales del servidor `geodesia2.inegi.org.mx` por SFTP, puerto `22`, usuario `rgnasftp`.
- **Fallback automático de servidor**: Si el servidor seleccionado no responde o no entrega archivos útiles, el asistente intenta automáticamente con la segunda opción disponible.
- **Carga automática de datos desde RINEX**: Al cargar un archivo RINEX, la herramienta puede poblar automáticamente estación, día del año (DOY), hora de inicio y hora de fin usando los metadatos detectados.
- **Normalización de unión RINEX**: El motor de unión ahora actualiza `TIME OF FIRST OBS` y `TIME OF LAST OBS` con base en las épocas reales del archivo resultante.
- **Control de duplicados de empalme**: La unión de observaciones elimina épocas repetidas entre fragmentos horarios para entregar un archivo continuo y más apto para postproceso geodésico.

### Cambiado
- **Servidor por defecto**: La descarga de bases INEGI prioriza ahora el nuevo servidor SFTP y conserva el FTP antiguo como respaldo operativo.
- **Motor de fusión universal reforzado**: La unión dejó de ser una concatenación simple de cabecera y cuerpos; ahora ordena fragmentos por tiempo cuando es posible y valida consistencia antes de generar el archivo final.
- **Unión conservadora RINEX 3.04**: Los fragmentos horarios RINEX 3 ya no se recortan a una intersección de observables comunes. El asistente conserva los registros horarios originales entregados por INEGI, ordena cronológicamente, elimina épocas duplicadas y actualiza los tiempos de cabecera.
- **Enrutamiento limpio hacia Postproceso**: El sidecar y el pipeline excluyen archivos derivados `*_CyC_*.rnx` al seleccionar la base RINEX 3 por defecto, priorizando el `.rnx` generado por el Asistente RINEX GNSS.
- **Escritura segura de descargas y descompresión**: Los motores de descarga y extracción escriben primero en archivos temporales `.part` y solo reemplazan el destino cuando el contenido es válido y no está vacío.
- **Compatibilidad conservadora de observables**: El Asistente RINEX conserva los códigos y observables originales; no realiza homologación ni sustitución de señales, dejando esa responsabilidad al módulo de postproceso cuando aplique.

### Corregido
- **Archivos finales reusados como entrada**: Se evita que una salida ya unificada sea tomada nuevamente como fragmento en una segunda ejecución dentro de la misma carpeta.
- **Archivos parciales o vacíos**: Se evita dejar archivos finales corruptos o de cero bytes cuando una descarga, extracción o unión falla.
- **Uniones RINEX con cabecera desfasada**: Se corrige el caso en que el archivo unificado mantenía tiempos de observación del primer fragmento aunque el cuerpo incluyera más horas.
- **Mezcla inválida de RINEX**: El motor rechaza uniones entre tipos distintos de archivo o entre observaciones con listas de observables incompatibles.

### Eliminado
- **Dependencia de concatenación simple en unión manual**: La ruta antigua `unir_fragmentos()` ahora delega en el motor universal reforzado para evitar salidas técnicamente débiles.

## [260417.0802] - 2026-04-17

### Añadido
- **Barra de Progreso en Tiempo Real**: Implementación de motores de descarga en *streaming* por bloques (`stream_http_progreso` y `stream_ftp_progreso`) que conectan el avance de todas las descargas (Base INEGI, Efemérides, Relojes, BRDC y Antenas) directamente a la barra gráfica de la interfaz de usuario.

### Cambiado
- **Priorización de Formatos Modernos**: Actualización de la lógica de guardado en el Sidecar (`_cyc.json`) y en el enrutador hacia Postproceso para dar prioridad absoluta a los archivos Base en RINEX 3 (`.rnx`) sobre RINEX 2 y a la Navegación Broadcast Combinada (`BRDC`) sobre la navegación clásica fraccionada.
- **Protocolos de Servidor (BRDC)**: Migración de la descarga del archivo de Navegación Combinada al protocolo FTP oficial de la ESA (`gssc.esa.int`) como fuente principal, manteniendo el servidor HTTP de BKG como respaldo (*fallback*).

### Corregido
- **Error de Certificado SSL en Descargas**: Se integró un contexto SSL permisivo (`ssl._create_unverified_context()`) en las peticiones a los servidores alemanes (BKG) para solucionar definitivamente los bloqueos por `[SSL: CERTIFICATE_VERIFY_FAILED]` en entornos Windows.

## [260416.1940] - 2026-04-16

### Añadido
- **Productos Geodésicos Complementarios**: Integración de descargas automáticas para archivos de Relojes (`.CLK`), Navegación Broadcast Combinada (`BRDC`) y archivo de calibración de Antenas (`igs20.atx`).
- **Nuevos Controles UI**: Incorporación de casillas de verificación (checkboxes) en el panel de opciones de descarga para gestionar de forma independiente los Relojes, BRDC y Antenas.
- **Descompresión Automática**: Implementación del motor local `extraer_gz` que descomprime automáticamente los archivos de órbitas, relojes y navegación, limpiando los comprimidos originales (`.gz`) para mantener el directorio ordenado.
- **Expansión del Sidecar (`_cyc.json`)**: El controlador ahora detecta y registra las rutas de los nuevos productos geodésicos (`clk`, `brdc`, `antena`) para inyectarlos en el flujo del módulo de Postproceso.

### Cambiado
- **Mirrors de Alta Disponibilidad**: Migración de los endpoints de descarga para BRDC y Antenas (anteriormente en servidores IGN/IGS) hacia el servidor espejo oficial BKG (Alemania) para mitigar fallos de tipo "HTTP 404 Not Found".
- **Actualización de Marco de Referencia**: Se cambió la descarga por defecto del archivo de calibración de antenas de `igs14.atx` al estándar actual `igs20.atx`.
- **Orquestación 100% Modular**: Se rediseñó el flujo principal para que las descargas operen de manera independiente. El sistema ahora evalúa correctamente si se solicitó o no interactuar con el FTP de INEGI antes de ejecutar el motor base.

### Corregido
- **Bug de Destrucción de Archivos Locales (Sobreescritura a 0 bytes)**: Se corrigió un problema crítico donde el sistema forzaba la apertura en modo escritura de archivos RINEX locales preexistentes (`MERI066.rnx`) si la casilla de INEGI estaba desmarcada, corrompiéndolos de manera irreversible.
- **Falsos Positivos de Error Global**: Se ajustó la validación final del orquestador para que el éxito en el procesamiento de datos locales (unión de archivos en la carpeta) no sea opacado ni cancelado por alertas de fallos en descargas web no solicitadas.
- **Crash de Interfaz (NameError)**: Solucionado un defecto en la inicialización de variables en el bloque final del controlador (`exito_sp3 is not defined`) que causaba una detención forzosa del programa.

## [260413.1016] - 2026-04-13

### Añadido
- **Bypass de Directorio (UX)**: Nuevo checkbox "Descargar en el directorio del Rover" en la interfaz que permite guardar los paquetes geodésicos descargados y unificados directamente en la misma carpeta del archivo original, omitiendo las ventanas de diálogo de Windows.

### Cambiado
- **Extracción de Metadatos Directa**: Se reescribió la lógica de inyección de datos (`cargar_desde_memoria`) para que la extracción y presentación de metadatos del Rover se realice de forma matemática e imperativa, eliminando simulaciones de clics falsos en la interfaz (`event_generate`).
- **Lógica de Guardado Automático**: El controlador ahora detecta el estado del nuevo checkbox para rutear los archivos automáticamente al directorio de origen sin interrumpir el flujo de automatización.

### Corregido
- **Auto-carga en Pipeline CyC**: Se solucionó el error de sincronización que impedía que el archivo Rover apareciera en la lista de trabajo al saltar desde el módulo de Postproceso (se integró el disparador faltante `after(300)` en el constructor principal).
- **Actualización Visual de Metadatos**: Reparado el problema visual donde el panel del Rover se quedaba "Esperando archivo..." tras una importación automática; ahora la interfaz se autocompleta instantáneamente al aterrizar en el módulo.

## [v260411.2001] - 2026-04-11

### 🚀 Añadido (Nuevas Características)
* **Fusión Multi-Track Automática (Observación + Navegación)**: Implementación de procesamiento paralelo por canales de extensión en el Orquestador. El sistema ahora agrupa y unifica de manera independiente los archivos `.26o`, `.26n`, `.26g` y `.26l` entregando un paquete geodésico completo.
* **Soporte Multi-Track Manual**: El controlador (`controlador.py`) ahora detecta inteligentemente la extensión de los archivos crudos arrastrados en el modo manual, separándolos en "carriles" y evitando la mezcla corrupta de datos de observación con órbitas de navegación.

### 🔄 Cambios (Refactorización)
* **Apertura de Filtro RINEX**: Se removió la restricción estricta de validación exclusiva para `OBSERVATION DATA` en el `motor_union_universal` (`modelo.py`), permitiendo la ingesta y fusión de archivos de navegación.
* **Textos de Ayuda UI**: Actualización de la prosa explicativa en la vista (`vista.py`) para instruir al operador sobre la nueva capacidad de retención, clasificación y unificación de archivos de navegación (GPS, GLONASS, Galileo).

## [v260410.1143] - 2026-04-10

### 🚀 Añadido (Nuevas Características)
* **Asistente Manual de Nomenclatura INEGI**: Calculadora visual que autocompleta el Día Juliano (DOY) y genera listas de nombres geodésicos (`STNDDD.YYO` y `.rnx`) según las horas de sesión del Rover.
* **Procesamiento Dual-Track (R2 y R3)**: El motor ahora separa e independiza automáticamente los archivos clásicos (RINEX 2.11) de los modernos (RINEX 3.04).
* **Triple Escudo de Efemérides (ESA)**: Implementado sistema de *fallback* automático (Final > Rápida > Ultra-Rápida) para asegurar siempre la descarga de órbitas precisas.
* **Auto-Limpieza Inteligente**: Bandera de persistencia de sesión que borra el "ruido" al vuelo, pero protege los archivos fuente `.zip` si el usuario activa el Checkbox de respaldo.
* **Tooltips de Ayuda Visual**: Integración de la clase `ToolTip` en toda la interfaz.

### 🔄 Cambios (Refactorización)
* **Identidad del Módulo**: Transición oficial de "Unión RINEX" a "Orquestador Descargas GNSS".
* **Motor de Fusión Universal**: Se unificaron algoritmos con Zero-Extraction directo a disco.
* **Nomenclatura Estándar DOY**: Adopción matemática del formato geodésico de Día Juliano.
* **Catálogo RGNA**: Actualización del marco de referencia explícito a "ITRF2008, época 2010.0".

### 🛠️ Correcciones (Bug Fixes)
* **Retención de ZIPs Bug**: Corregido desplazamiento de argumentos en el controlador.
* **Empaquetado de Interfaz (Tkinter)**: Ajuste de anclaje `tk.BOTTOM` para elementos críticos.
* **Importación Faltante**: Solucionado el error de `os` en el modo manual.
