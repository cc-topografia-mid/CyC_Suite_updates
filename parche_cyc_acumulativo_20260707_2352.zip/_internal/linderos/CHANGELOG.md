# 🚧 CHANGELOG - Módulo Linderos
**CyC Topografía Suite**

Todas las actualizaciones notables del módulo de **Control y Replanteo de Colindancias (Linderos)** se documentarán en este archivo. El sistema de versionado sigue la nomenclatura interna de compilación `vYYMMDD.HHMM`.

---

## [v260703.1955]

### Cambiado
* Eliminación de compuertas funcionales dependientes del estado de licencia en el controlador de Linderos.
* Sustitución de la validación `BASICO`/`Pro` por eventos no bloqueantes enviados a `monetizacion.disparar_donacion(...)`.
* Las acciones de guardar gráfico, exportar reportes TXT/PDF, guardar sesión, guardar como y cargar sesión quedan disponibles para usuarios **Basico** y **Donador** por igual.
* La integración con monetización queda limitada a banners, avisos o reconocimiento de apoyo, sin impedir cálculos, exportaciones, sesiones ni flujos técnicos.

### Política aplicada
* Se alinea el módulo con `README_LICENCIAS_MONETIZACION_USUARIO.md` y `README_INSTALADOR.md`: la licencia reconoce estado y apoyo, pero no bloquea ni desbloquea herramientas.

## [v260625.1614]

### Cambiado
* Actualización de la versión central del módulo Linderos en `versiones.py`.
* Adopción de los valores neutros oficiales de la guía visual CyC para fondo, superficies, paneles, bordes, texto, texto secundario y controles deshabilitados.
* Eliminación de variantes oscuras de verde y amarillo en estados hover; los controles conservan el mismo color corporativo y comunican interacción mediante relieve.
* Definición de tres niveles visuales de acción: primario verde, secundario amarillo y terciario neutro con borde verde.
* Clasificación de cálculo, validación y proyección como acciones primarias; exportaciones como acciones secundarias; navegación, edición y sesión como acciones terciarias.
* Incremento de la tipografía monoespaciada de memorias y resultados técnicos a 10 puntos.
* Normalización del padding interno de secciones y filas operativas.
* Reducción del título de vista previa a la escala tipográfica establecida para encabezados de panel.
* Sustitución de colores azul y naranja residuales en los botones de exportación por amarillo corporativo.
* Uniformación de etiquetas de formulario mediante anchos controlados y alineación izquierda, manteniendo variantes compactas en filas con varios controles.
* Simplificación del estado inicial para reducir instrucciones extensas y priorizar la acción operativa.
* Incorporación de una barra de estado corporativa: verde para datos válidos, amarillo para advertencias y borde neutro para espera.
* Protección de la memoria de cálculo y el resumen interactivo como salidas de solo lectura, habilitándolas únicamente durante su actualización programática.
* Ajuste de encabezados técnicos del resumen a Consolas 11 y verde corporativo.
* Extracción de la escritura TXT y construcción PDF a `linderos/reporteador.py`, un servicio sin dependencias de Tkinter.
* Traslado de permisos Pro, selección de rutas, coordinación de exportaciones y mensajes de resultado al controlador.
* Eliminación de la lógica duplicada de licencia y monetización que permanecía dentro de la vista.
* Sustitución de acciones directas de exportación en los botones por eventos delegados al controlador.
* Eliminación completa de las dependencias ReportLab desde `vista.py`; ReportLab queda encapsulado en el servicio de reportes.
* Incorporación de una interfaz pública mínima entre controlador y vista para obtener contenido, configuración, paginación, gráfico temporal y textos visibles sin acceder a implementaciones privadas.
* Traslado de la construcción del editor de códigos topográficos desde el controlador hacia la vista, dejando al controlador únicamente la preparación y actualización de datos.
* Traslado del montaje y ciclo de vida del canvas y la barra de Matplotlib hacia la vista.
* Eliminación de colores visuales aislados y widgets `ttk` creados directamente desde el controlador.
* Corrección de botones azules provocados por la sobrescritura global de estilos `ttk` desde otros módulos de la Suite.
* Sustitución de botones operativos por controles Tk con colores CyC explícitos, inmunes a cambios posteriores del tema global.
* Sustitución de etiquetas, encabezados, filas y marcos de sección sensibles al tema por controles con fondo y texto explícitos.
* Eliminación de los recuadros grises que aparecían detrás de títulos y textos al perderse los estilos locales.
* Conversión de la pestaña Datos completa a un contenedor vertical desplazable para impedir que la sección **Proyecto y Sesión** quede recortada en ventanas de altura limitada.
* Incorporación de desplazamiento local con rueda del ratón sobre paneles y etiquetas, sin enlaces globales y respetando controles editables.
* Conservación de la barra de desplazamiento visible para que todas las acciones inferiores permanezcan localizables y accesibles.
* Corrección definitiva de botones azules bajo `ttkbootstrap`: el tema `litera` interceptaba el constructor de `tk.Button` y reemplazaba los colores declarados por su primario `#4582EC`.
* Desactivación explícita de `autostyle` en botones cuando `ttkbootstrap` está activo y reaplicación posterior de fondo, texto, estado activo y borde.
* Aplicación de la misma protección a la capa `CompatButton`, incluyendo controles compactos de configuración PDF.
* Corrección del ancho efectivo de los selectores basados en `ttk.Combobox` para que el desplegable muestre completas las opciones largas, incluyendo **Integrar en Reporte** y **Referenciar como Anexo**.
* Reorganización de la fila **10. Residuos** en columnas dedicadas para impedir que el selector o la acción lateral se compriman visualmente.

### Decisión de alcance
* La adaptación a una sola columna para pantallas estrechas se pospone como funcionalidad futura; el módulo continuará optimizado para monitores anchos.

### Preparado
* Conservación de la capa i18n existente y de las referencias a widgets para facilitar una internacionalización integral posterior, sin ampliar todavía el catálogo de traducciones.

## [v260625.0859]

### Cambiado
* Actualización de la versión central del módulo Linderos en `versiones.py` conforme al esquema `AAMMDD.HHMM`.
* Homologación visual con el módulo de Postproceso mediante paneles equilibrados, superficies blancas, fondo general gris claro y secciones tipo tarjeta.
* Sustitución de acentos azules por verde corporativo `#1A7B3E` y amarillo corporativo `#FFC439`.
* Rediseño de pestañas, botones, encabezados de tablas, estados iniciales y controles compactos para mantener una jerarquía visual uniforme en la Suite.
* Ajuste del panel dividido para permitir crecimiento proporcional de ambos lados y aprovechar mejor resoluciones amplias.
* Limitación de las paletas de exportación corporativas a variantes verde y amarilla de CyC.
* Migración del motor lineal a la ecuación general normalizada `Ax + By + C = 0`, conservando compatibilidad con sesiones que almacenan pendiente e intercepto.
* Sustitución de extremos extendidos artificialmente por extremos físicos obtenidos al proyectar los puntos utilizados sobre la recta ajustada.
* Actualización de OLS, RANSAC y ODR para aceptar cualquier orientación del lindero, incluidas rectas verticales.
* Clasificación de vértices como cruces directos o cruces próximos a extremos; las prolongaciones lejanas ya no se exportan como vértices CAD.
* Sustitución de la selección exclusiva por R² por una puntuación multicriterio basada en R² geométrico, RMSE relativo a tolerancia, proporción de inliers y robustez del método.
* Incorporación de offsets firmados respecto a cada recta ajustada, incluyendo máximo absoluto, promedio, rango positivo/negativo y cantidad de puntos fuera de tolerancia.
* Ampliación del gestor de tramos, resumen interactivo, gráfico y reporte técnico para mostrar score, offsets y excedencias.
* Resaltado gráfico en amarillo corporativo de los puntos cuyo desfase absoluto supera la tolerancia configurada.
* Implementación de la sección 9 de cierre poligonal mediante ordenamiento topológico de tramos y vértices.
* Cálculo de error de cierre X/Y, cierre lineal, perímetro, precisión relativa y brechas entre extremos físicos.
* Validación explícita de cadenas abiertas, ramificaciones, tramos aislados y redes con más de un ciclo, evitando reportar cierres ficticios.
* Implementación de la opción **Integrar en Reporte** para residuos y offsets, con tablas paginables en bloques de veinte puntos.
* Implementación de la opción **Referenciar como Anexo**, incluyendo resumen estadístico y referencia al CSV detallado.
* Ampliación del anexo CSV con offset firmado, residuo ortogonal, tramo asignado y estado del punto.
* Implementación matemática del modelo circular mediante mínimos cuadrados no lineales con estabilización en coordenadas locales para datos UTM.
* Competencia automática entre polinomio de segundo grado y círculo cuando se selecciona geometría curva.
* Determinación del centro, radio, amplitud angular, extremos observados y longitud del arco.
* Integración de residuos radiales firmados, RMSE circular y puntos fuera de tolerancia.
* Representación gráfica del arco o círculo completo, incluyendo marcador del centro.
* Ampliación de la calculadora para devolver las dos soluciones posibles de X o Y sobre un círculo.
* Inclusión de parámetros circulares y geometría del arco en el resumen interactivo y el reporte técnico.
* Configuración de mínimo de puntos por tramo y máximo de tramos para los modos automáticos.
* Selección automática del número de grupos Auto Z mediante índice Silhouette, con opción de fijar manualmente entre 2 y 10 niveles.
* Incorporación de centros Z detectados, confianza de agrupación y diagnóstico de puntos remanentes o grupos omitidos.
* Eliminación del límite fijo de cinco tramos en Auto XY y soporte configurable de hasta veinte detecciones.
* Sustitución del formato de sesión basado en `pickle` por un contenedor ZIP con manifiesto JSON validado y versionado.
* Persistencia completa de entrada, columnas, análisis, parámetros Auto, escala, reporte y configuración PDF.
* Detección de sesiones heredadas con advertencia explícita antes de permitir su carga.
* Centralización de la captura y restauración de configuraciones para reducir duplicación entre reporte y sesiones.
* Eliminación de referencias circulares dentro de las comparativas de modelos para permitir serialización segura y archivos más compactos.

### Corregido
* Eliminación de la singularidad y resultados inestables en linderos Norte-Sur o con pendiente prácticamente infinita.
* Cálculo de residuos ortogonales unificado para rectas horizontales, oblicuas y verticales.
* Calculadora de proyección adaptada para informar cuando una recta vertical u horizontal no permite resolver un valor único.
* Corrección del error `TclError: invalid command name ... notebook` al usar la rueda del ratón después de cambiar o cerrar el módulo Linderos.
* Sustitución del enlace global `bind_all(<MouseWheel>)` por un enlace local al canvas de vista previa.
* Cancelación de trabajos diferidos de renderizado y validación al destruir la vista, evitando callbacks sobre widgets inexistentes.

## [v260625.0849]

### Añadido
* Validación automática de datos pegados desde Excel con resumen de filas válidas, rechazadas, columnas, separador y códigos detectados.
* Vista previa tabular de las coordenadas interpretadas antes de ejecutar el ajuste.
* Botón principal **Validar y calcular linderos** dentro de la pestaña Datos.
* Controles de procesamiento inicial en la misma pestaña para seleccionar modo, geometría y tolerancia sin navegar previamente a Modelos.
* Mensajes explícitos para entradas vacías, columnas inválidas, tolerancias no positivas y conjuntos sin modelos calculables.

### Cambiado
* El separador de entrada ahora utiliza detección automática de tabuladores, punto y coma, espacios o comas.
* La importación conserva inicialmente los valores como texto para normalizar coordenadas con separadores regionales.
* El área para pegar contenido de Excel aumentó de tamaño y el panel derecho presenta instrucciones y diagnóstico antes del cálculo.

### Corregido
* Lectura de coordenadas con coma de miles, por ejemplo `340,207.2910` y `2,305,127.3640`.
* Lectura de coordenadas con formato europeo, por ejemplo `340.207,2910`.
* Retornos silenciosos durante la validación que dejaban al operador sin explicación sobre por qué no comenzaba el cálculo.

## [v260428.1833]

### Añadido
* Integración de una vista previa de exportación en el panel derecho del módulo, con representación multipágina y renderizado del reporte técnico dentro de una maqueta tipo hoja.
* Incorporación de controles de configuración PDF en tiempo real para papel, paleta visual, tamaño de texto, márgenes, paginación, ajuste de texto y títulos en negrita.
* Inclusión de la vista gráfica del ajuste dentro del reporte técnico mediante marcador Markdown y renderizado tanto en la vista previa como en la exportación.
* Integración del sistema `i18n` de la Suite en la interfaz de Linderos, con suscripción activa a cambios globales de idioma.
* Traducción del generador de reportes en `modelo.py`, permitiendo que el contenido exportado respete el idioma activo de la Suite.

### Cambiado
* Migración de la interfaz principal del módulo a `CustomTkinter`, conservando la estructura operativa existente pero alineándola con el estándar visual moderno de la Suite.
* Rediseño del layout principal para usar un panel derecho ajustable en lugar de un ancho fijo, mejorando la visibilidad del formulario y del visor de reporte.
* Reestructuración del reporte técnico para generarse en sintaxis Markdown enriquecida, con encabezados, listas, tablas y bloques consistentes para TXT, vista previa y PDF.
* Homologación visual de la exportación de Linderos con otros módulos de la Suite, incluyendo configuración de paletas y comportamiento de vista previa más cercano al resultado final exportado.
* Ajuste del bloque “Proyecto y Sesión” para mejorar legibilidad de botones y evitar recortes de texto en acciones de guardado y carga.

### Corregido
* Corrección del desbordamiento y traslape entre el título del documento y el cuerpo del reporte en la vista previa.
* Solucionado el problema donde la vista previa mostraba artefactos de Markdown sin procesar, como encabezados `###` visibles y tablas renderizadas como texto plano.
* Ajustado el paginado del reporte para evitar cortes de bloques, tablas o secciones fuera del área útil de la página.
* Corregido el comportamiento de las opciones de configuración PDF para evitar colapsos y ocultamiento parcial de controles en la interfaz.
* Solucionado el renderizado de la imagen del gráfico dentro de la vista previa cuando el reporte final incluía la sección de vista gráfica.
* Corregido el cambio dinámico de idioma en pestañas y controles del módulo, incluyendo el fallo `KeyError: 'Datos'` provocado por el renombrado de pestañas en `CTkTabview`.
* Reparada la actualización en tiempo real de textos visibles, encabezados y elementos de previsualización al cambiar entre español, inglés y portugués.

## [v260408.1630]

### ✨ Añadido
* **Alerta de Invasión (Offset):** Implementación de un algoritmo que calcula la distancia perpendicular de un punto levantado hacia la línea teórica del lindero, resaltando la fila en rojo si la invasión o el desfase supera la tolerancia constructiva.
* **Modo Aprendizaje:** Integración de la clase `ToolTip` en todos los controles principales para asistir al operador en el análisis de colindancias, respetando el estándar visual de la Suite.

### 🛠️ Modificado
* **UI/UX:** Adopción del formato de "Pantalla Dividida" (50% Área de Tablas / 50% Panel de Análisis Geométrico y Legal).
* **Motor de Rumbos:** Optimización de la lógica trigonométrica para la asignación y visualización correcta de los cuadrantes geográficos (NE, SE, SW, NW).

---

## [v260407.1100]

### 🐛 Corregido
* **Singularidad Matemática:** Solucionado el error de división por cero (`ZeroDivisionError`) que colapsaba el sistema al intentar calcular la pendiente (m) en linderos que eran perfectamente verticales alineados al eje Norte-Sur (X1 = X2).
* **Gestión de Memoria:** Corrección de un fallo que duplicaba los puntos *as-built* en la tabla al recargar un archivo CSV modificado sin haber limpiado la sesión previa de la memoria.

---

## [v260406.0900]

### ✨ Añadido
* 🚀 Lanzamiento inicial del Módulo Linderos.
* Estructura base del patrón MVC (Modelo, Vista, Controlador).
* Ingesta de archivos CSV con coordenadas teóricas del polígono de diseño.
* Rutina analítica básica para el cálculo de distancias perimetrales entre vértices de la propiedad.
