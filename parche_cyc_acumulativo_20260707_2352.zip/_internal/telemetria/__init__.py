"""Telemetria anonima para metricas comerciales de CyC Suite."""

from .cliente import (
    consentimiento_activo,
    establecer_consentimiento,
    inicializar,
    reportar_app_closed,
    reportar_app_opened,
    reportar_banner_click,
    reportar_banner_impression,
    reportar_evento,
    reportar_heartbeat,
    reportar_module_opened,
)

__all__ = [
    "consentimiento_activo",
    "establecer_consentimiento",
    "inicializar",
    "reportar_app_closed",
    "reportar_app_opened",
    "reportar_banner_click",
    "reportar_banner_impression",
    "reportar_evento",
    "reportar_heartbeat",
    "reportar_module_opened",
]
